import logging
from typing import Callable
from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware
from ..services.cache_service import get_cache_service

logger = logging.getLogger(__name__)


class CacheMiddleware(BaseHTTPMiddleware):
    def __init__(self, app, cache_ttl: int = 300):
        super().__init__(app)
        self.cache_ttl = cache_ttl
        self.cache_service = get_cache_service()

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        # Only cache GET requests
        if request.method != "GET":
            return await call_next(request)
        
        # Generate cache key based on URL and query parameters
        cache_key = f"{request.url.path}:{str(request.query_params)}"
        
        # Try to get from cache
        cached_response = self.cache_service.get("http", cache_key)
        if cached_response:
            logger.debug(f"Cache hit for {cache_key}")
            return Response(
                content=cached_response["content"],
                status_code=cached_response["status_code"],
                headers=cached_response["headers"],
                media_type=cached_response["media_type"]
            )
        
        # Cache miss, process request
        response = await call_next(request)
        
        # Only cache successful responses
        if response.status_code == 200:
            try:
                # Read response body
                body = b""
                async for chunk in response.body_iterator:
                    body += chunk
                
                # Cache the response
                cache_data = {
                    "content": body.decode(),
                    "status_code": response.status_code,
                    "headers": dict(response.headers),
                    "media_type": response.media_type
                }
                
                self.cache_service.set("http", cache_key, cache_data, self.cache_ttl)
                logger.debug(f"Cached response for {cache_key}")
                
                # Return response with the body
                return Response(
                    content=body,
                    status_code=response.status_code,
                    headers=response.headers,
                    media_type=response.media_type
                )
            except Exception as e:
                logger.error(f"Error caching response: {e}")
        
        return response
