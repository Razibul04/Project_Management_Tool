import time
from typing import Dict
from fastapi import Request, HTTPException
from fastapi.responses import JSONResponse
from ..config import settings

# In-memory rate limiter (use Redis in production)
rate_limit_storage: Dict[str, Dict] = {}


class RateLimiter:
    def __init__(self, requests: int = None, window: int = None):
        self.requests = requests or settings.rate_limit_requests
        self.window = window or settings.rate_limit_window

    async def __call__(self, request: Request):
        client_ip = request.client.host
        current_time = time.time()
        
        # Clean old entries
        self._cleanup_old_entries(current_time)
        
        # Check rate limit
        if client_ip in rate_limit_storage:
            client_data = rate_limit_storage[client_ip]
            
            # Reset if window has passed
            if current_time - client_data['window_start'] > self.window:
                client_data['count'] = 1
                client_data['window_start'] = current_time
            else:
                client_data['count'] += 1
                
                if client_data['count'] > self.requests:
                    raise HTTPException(
                        status_code=429,
                        detail=f"Rate limit exceeded. Maximum {self.requests} requests per {self.window} seconds."
                    )
        else:
            rate_limit_storage[client_ip] = {
                'count': 1,
                'window_start': current_time
            }

    def _cleanup_old_entries(self, current_time: float):
        """Remove old entries to prevent memory leaks."""
        to_remove = []
        for ip, data in rate_limit_storage.items():
            if current_time - data['window_start'] > self.window * 2:
                to_remove.append(ip)
        
        for ip in to_remove:
            del rate_limit_storage[ip]


# Global rate limiter instance
rate_limiter = RateLimiter()
