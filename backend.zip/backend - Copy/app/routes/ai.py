from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from typing import List, Optional
from ..models.user import User, UserRole
from ..services.ai_service import AIService, get_ai_service
from ..routes.auth import get_current_user

router = APIRouter(prefix="/ai", tags=["ai"])


class UserStoryRequest(BaseModel):
    project_description: str
    num_stories: int = 5


class UserStoryResponse(BaseModel):
    stories: List[str]


class TaskGenerationRequest(BaseModel):
    user_stories: List[str]


class TaskGenerationResponse(BaseModel):
    tasks: List[dict]


@router.post("/generate-user-stories", response_model=UserStoryResponse)
def generate_user_stories(
    request: UserStoryRequest,
    current_user: User = Depends(get_current_user),
    ai_service: AIService = Depends(get_ai_service)
):
    """Generate user stories for a project using AI."""
    # Only allow project managers and admins to use AI features
    if current_user.role not in [UserRole.ADMIN, UserRole.PROJECT_MANAGER]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only project managers and admins can use AI features"
        )
    
    try:
        stories = ai_service.generate_user_stories(
            request.project_description,
            request.num_stories
        )
        return UserStoryResponse(stories=stories)
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to generate user stories: {str(e)}"
        )


@router.post("/generate-tasks", response_model=TaskGenerationResponse)
def generate_tasks_from_stories(
    request: TaskGenerationRequest,
    current_user: User = Depends(get_current_user),
    ai_service: AIService = Depends(get_ai_service)
):
    """Generate tasks from user stories using AI."""
    # Only allow project managers and admins to use AI features
    if current_user.role not in [UserRole.ADMIN, UserRole.PROJECT_MANAGER]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only project managers and admins can use AI features"
        )
    
    try:
        tasks = ai_service.generate_tasks_from_stories(request.user_stories)
        return TaskGenerationResponse(tasks=tasks)
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to generate tasks: {str(e)}"
        )
