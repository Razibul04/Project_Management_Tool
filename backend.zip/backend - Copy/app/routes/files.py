import os
import uuid
import mimetypes
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form, status
from sqlalchemy.orm import Session
from typing import Optional, List
from ..database import get_db
from ..models.user import User
from ..models.file import File as FileModel
from ..models.project import Project
from ..models.task import Task
from ..schemas.file_schema import FileResponse, FileUploadResponse
from ..routes.auth import get_current_user
from ..config import settings

router = APIRouter(prefix="/files", tags=["files"])


def get_file_extension(filename: str) -> str:
    """Get file extension from filename."""
    return os.path.splitext(filename)[1].lower()


def is_allowed_file(filename: str) -> bool:
    """Check if file type is allowed."""
    allowed_extensions = {
        '.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp',  # Images
        '.pdf', '.doc', '.docx', '.txt', '.rtf',  # Documents
        '.xls', '.xlsx', '.csv',  # Spreadsheets
        '.ppt', '.pptx',  # Presentations
        '.zip', '.rar', '.7z',  # Archives
        '.mp4', '.avi', '.mov', '.wmv',  # Videos
        '.mp3', '.wav', '.flac',  # Audio
    }
    return get_file_extension(filename) in allowed_extensions


def get_mime_type(filename: str) -> str:
    """Get MIME type for file."""
    mime_type, _ = mimetypes.guess_type(filename)
    return mime_type or 'application/octet-stream'


@router.post("/upload", response_model=FileUploadResponse)
async def upload_file(
    file: UploadFile = File(...),
    project_id: Optional[int] = Form(None),
    task_id: Optional[int] = Form(None),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Upload a file to a project or task."""
    
    # Validate file
    if not file.filename:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No file provided"
        )
    
    if not is_allowed_file(file.filename):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="File type not allowed"
        )
    
    # Check file size
    file_content = await file.read()
    if len(file_content) > settings.max_file_size:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"File too large. Maximum size: {settings.max_file_size} bytes"
        )
    
    # Validate project/task access
    if project_id:
        project = db.query(Project).filter(Project.id == project_id).first()
        if not project:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Project not found"
            )
        # Check if user has access to project
        if current_user.role.value != "admin" and project.owner_id != current_user.id:
            # Check if user is project member
            from ..models.project import ProjectMember
            member = db.query(ProjectMember).filter(
                ProjectMember.project_id == project_id,
                ProjectMember.user_id == current_user.id
            ).first()
            if not member:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Access denied to this project"
                )
    
    if task_id:
        task = db.query(Task).filter(Task.id == task_id).first()
        if not task:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Task not found"
            )
        # Check if user has access to task's project
        if current_user.role.value != "admin" and task.project.owner_id != current_user.id:
            from ..models.project import ProjectMember
            member = db.query(ProjectMember).filter(
                ProjectMember.project_id == task.project_id,
                ProjectMember.user_id == current_user.id
            ).first()
            if not member:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Access denied to this task"
                )
    
    # Generate unique filename
    file_extension = get_file_extension(file.filename)
    unique_filename = f"{uuid.uuid4()}{file_extension}"
    
    # Create upload directory if it doesn't exist
    upload_dir = settings.upload_directory
    os.makedirs(upload_dir, exist_ok=True)
    
    # Save file
    file_path = os.path.join(upload_dir, unique_filename)
    with open(file_path, "wb") as buffer:
        buffer.write(file_content)
    
    # Create file record
    db_file = FileModel(
        filename=unique_filename,
        original_filename=file.filename,
        file_path=file_path,
        file_size=len(file_content),
        mime_type=get_mime_type(file.filename),
        uploaded_by_id=current_user.id,
        project_id=project_id,
        task_id=task_id
    )
    
    db.add(db_file)
    db.commit()
    db.refresh(db_file)
    
    return FileUploadResponse(
        message="File uploaded successfully",
        file=db_file
    )


@router.get("/", response_model=List[FileResponse])
def get_files(
    project_id: Optional[int] = None,
    task_id: Optional[int] = None,
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Get files for a project or task."""
    query = db.query(FileModel)
    
    if project_id:
        query = query.filter(FileModel.project_id == project_id)
    elif task_id:
        query = query.filter(FileModel.task_id == task_id)
    else:
        # If no specific project/task, return user's files
        query = query.filter(FileModel.uploaded_by_id == current_user.id)
    
    files = query.offset(skip).limit(limit).all()
    return files


@router.get("/{file_id}", response_model=FileResponse)
def get_file(
    file_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Get a specific file."""
    file = db.query(FileModel).filter(FileModel.id == file_id).first()
    if not file:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="File not found"
        )
    
    # Check access permissions
    if current_user.role.value != "admin" and file.uploaded_by_id != current_user.id:
        # Check if user has access to the project/task
        if file.project_id:
            from ..models.project import ProjectMember
            member = db.query(ProjectMember).filter(
                ProjectMember.project_id == file.project_id,
                ProjectMember.user_id == current_user.id
            ).first()
            if not member:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Access denied to this file"
                )
        elif file.task_id:
            task = db.query(Task).filter(Task.id == file.task_id).first()
            if task:
                from ..models.project import ProjectMember
                member = db.query(ProjectMember).filter(
                    ProjectMember.project_id == task.project_id,
                    ProjectMember.user_id == current_user.id
                ).first()
                if not member:
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail="Access denied to this file"
                    )
    
    return file


@router.delete("/{file_id}")
def delete_file(
    file_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Delete a file."""
    file = db.query(FileModel).filter(FileModel.id == file_id).first()
    if not file:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="File not found"
        )
    
    # Check permissions
    if current_user.role.value != "admin" and file.uploaded_by_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only the uploader or admin can delete this file"
        )
    
    # Delete physical file
    if os.path.exists(file.file_path):
        os.remove(file.file_path)
    
    # Delete database record
    db.delete(file)
    db.commit()
    
    return {"message": "File deleted successfully"}


@router.get("/{file_id}/download")
def download_file(
    file_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Download a file."""
    file = db.query(FileModel).filter(FileModel.id == file_id).first()
    if not file:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="File not found"
        )
    
    # Check access permissions (same as get_file)
    if current_user.role.value != "admin" and file.uploaded_by_id != current_user.id:
        if file.project_id:
            from ..models.project import ProjectMember
            member = db.query(ProjectMember).filter(
                ProjectMember.project_id == file.project_id,
                ProjectMember.user_id == current_user.id
            ).first()
            if not member:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Access denied to this file"
                )
        elif file.task_id:
            task = db.query(Task).filter(Task.id == file.task_id).first()
            if task:
                from ..models.project import ProjectMember
                member = db.query(ProjectMember).filter(
                    ProjectMember.project_id == task.project_id,
                    ProjectMember.user_id == current_user.id
                ).first()
                if not member:
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail="Access denied to this file"
                    )
    
    if not os.path.exists(file.file_path):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="File not found on disk"
        )
    
    from fastapi.responses import FileResponse
    return FileResponse(
        path=file.file_path,
        filename=file.original_filename,
        media_type=file.mime_type
    )
