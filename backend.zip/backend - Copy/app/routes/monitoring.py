from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from ..database import get_db
from ..services.monitoring_service import MonitoringService, get_monitoring_service

router = APIRouter(prefix="/monitoring", tags=["monitoring"])


@router.get("/health")
def health_check(
    db: Session = Depends(get_db),
    monitoring_service: MonitoringService = Depends(get_monitoring_service)
):
    """Get application health status."""
    health_status = monitoring_service.get_health_status(db)
    
    if health_status["status"] == "unhealthy":
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=health_status
        )
    
    return health_status


@router.get("/metrics")
def get_metrics(
    db: Session = Depends(get_db),
    monitoring_service: MonitoringService = Depends(get_monitoring_service)
):
    """Get application metrics."""
    system_metrics = monitoring_service.get_system_metrics()
    database_metrics = monitoring_service.get_database_metrics(db)
    application_metrics = monitoring_service.get_application_metrics()
    
    return {
        "system": system_metrics,
        "database": database_metrics,
        "application": application_metrics
    }


@router.get("/metrics/system")
def get_system_metrics(
    monitoring_service: MonitoringService = Depends(get_monitoring_service)
):
    """Get system performance metrics."""
    return monitoring_service.get_system_metrics()


@router.get("/metrics/database")
def get_database_metrics(
    db: Session = Depends(get_db),
    monitoring_service: MonitoringService = Depends(get_monitoring_service)
):
    """Get database performance metrics."""
    return monitoring_service.get_database_metrics(db)


@router.get("/metrics/application")
def get_application_metrics(
    monitoring_service: MonitoringService = Depends(get_monitoring_service)
):
    """Get application-specific metrics."""
    return monitoring_service.get_application_metrics()
