from fastapi import APIRouter, Depends, Query, HTTPException
from sqlalchemy.orm import Session
from typing import List, Optional
from ..database import get_db
from ..models.user import User
from ..services.search_service import SearchService
from ..routes.auth import get_current_user

router = APIRouter(prefix="/search", tags=["search"])


def get_search_service(db: Session = Depends(get_db)) -> SearchService:
    """Get search service instance."""
    return SearchService(db)


@router.get("/projects")
def search_projects(
    q: str = Query(..., description="Search query"),
    status: Optional[str] = Query(None, description="Filter by project status"),
    owner_id: Optional[int] = Query(None, description="Filter by owner ID"),
    limit: int = Query(20, ge=1, le=100, description="Number of results to return"),
    offset: int = Query(0, ge=0, description="Number of results to skip"),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    search_service: SearchService = Depends(get_search_service)
):
    """Search projects with advanced filtering."""
    results = search_service.search_projects(
        query=q,
        user_id=current_user.id,
        user_role=current_user.role.value,
        status=status,
        owner_id=owner_id,
        limit=limit,
        offset=offset
    )
    return results


@router.get("/tasks")
def search_tasks(
    q: str = Query(..., description="Search query"),
    project_id: Optional[int] = Query(None, description="Filter by project ID"),
    status: Optional[str] = Query(None, description="Filter by task status"),
    priority: Optional[str] = Query(None, description="Filter by task priority"),
    assigned_to: Optional[int] = Query(None, description="Filter by assigned user ID"),
    due_date_from: Optional[str] = Query(None, description="Filter by due date from (YYYY-MM-DD)"),
    due_date_to: Optional[str] = Query(None, description="Filter by due date to (YYYY-MM-DD)"),
    limit: int = Query(20, ge=1, le=100, description="Number of results to return"),
    offset: int = Query(0, ge=0, description="Number of results to skip"),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    search_service: SearchService = Depends(get_search_service)
):
    """Search tasks with advanced filtering."""
    results = search_service.search_tasks(
        query=q,
        user_id=current_user.id,
        user_role=current_user.role.value,
        project_id=project_id,
        status=status,
        priority=priority,
        assigned_to=assigned_to,
        due_date_from=due_date_from,
        due_date_to=due_date_to,
        limit=limit,
        offset=offset
    )
    return results


@router.get("/users")
def search_users(
    q: str = Query(..., description="Search query"),
    role: Optional[str] = Query(None, description="Filter by user role"),
    limit: int = Query(20, ge=1, le=100, description="Number of results to return"),
    offset: int = Query(0, ge=0, description="Number of results to skip"),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    search_service: SearchService = Depends(get_search_service)
):
    """Search users with filtering."""
    results = search_service.search_users(
        query=q,
        user_id=current_user.id,
        user_role=current_user.role.value,
        role_filter=role,
        limit=limit,
        offset=offset
    )
    return results


@router.get("/comments")
def search_comments(
    q: str = Query(..., description="Search query"),
    task_id: Optional[int] = Query(None, description="Filter by task ID"),
    project_id: Optional[int] = Query(None, description="Filter by project ID"),
    limit: int = Query(20, ge=1, le=100, description="Number of results to return"),
    offset: int = Query(0, ge=0, description="Number of results to skip"),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    search_service: SearchService = Depends(get_search_service)
):
    """Search comments with filtering."""
    results = search_service.search_comments(
        query=q,
        user_id=current_user.id,
        user_role=current_user.role.value,
        task_id=task_id,
        project_id=project_id,
        limit=limit,
        offset=offset
    )
    return results


@router.get("/files")
def search_files(
    q: str = Query(..., description="Search query"),
    project_id: Optional[int] = Query(None, description="Filter by project ID"),
    task_id: Optional[int] = Query(None, description="Filter by task ID"),
    file_type: Optional[str] = Query(None, description="Filter by file type (e.g., 'image', 'pdf')"),
    limit: int = Query(20, ge=1, le=100, description="Number of results to return"),
    offset: int = Query(0, ge=0, description="Number of results to skip"),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    search_service: SearchService = Depends(get_search_service)
):
    """Search files with filtering."""
    results = search_service.search_files(
        query=q,
        user_id=current_user.id,
        user_role=current_user.role.value,
        project_id=project_id,
        task_id=task_id,
        file_type=file_type,
        limit=limit,
        offset=offset
    )
    return results


@router.get("/global")
def global_search(
    q: str = Query(..., description="Search query"),
    types: Optional[List[str]] = Query(None, description="Search types: projects, tasks, users, comments, files"),
    limit: int = Query(10, ge=1, le=50, description="Number of results per type"),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    search_service: SearchService = Depends(get_search_service)
):
    """Perform global search across all entities."""
    if not types:
        types = ["projects", "tasks", "users", "comments", "files"]
    
    results = search_service.global_search(
        query=q,
        user_id=current_user.id,
        user_role=current_user.role.value,
        search_types=types,
        limit=limit
    )
    return results


@router.get("/suggestions")
def get_search_suggestions(
    q: str = Query(..., min_length=2, description="Search query (minimum 2 characters)"),
    limit: int = Query(5, ge=1, le=20, description="Number of suggestions to return"),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    search_service: SearchService = Depends(get_search_service)
):
    """Get search suggestions based on query."""
    suggestions = search_service.get_search_suggestions(
        query=q,
        user_id=current_user.id,
        user_role=current_user.role.value,
        limit=limit
    )
    return {"suggestions": suggestions}
