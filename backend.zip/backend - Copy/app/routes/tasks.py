from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from sqlalchemy import and_, func
from typing import List
from datetime import datetime
from ..database import get_db
from ..models.user import User, UserRole
from ..models.project import Project, ProjectMember
from ..models.task import Task, Comment
from ..schemas.task_schema import (
    TaskCreate, TaskUpdate, TaskResponse, TaskWithDetails,
    CommentCreate, CommentResponse, DashboardStats
)
from ..services.auth_service import AuthService, get_auth_service
from ..routes.auth import get_current_user

router = APIRouter(prefix="/tasks", tags=["tasks"])


@router.post("/", response_model=TaskResponse)
def create_task(
    task_data: TaskCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    auth_service: AuthService = Depends(get_auth_service)
):
    """Create a new task."""
    # Check if user has access to the project
    project = db.query(Project).filter(Project.id == task_data.project_id).first()
    if not project:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Project not found"
        )
    
    # Check permissions
    if current_user.role == UserRole.ADMIN or project.owner_id == current_user.id:
        pass  # Allowed
    else:
        member = db.query(ProjectMember).filter(
            ProjectMember.project_id == task_data.project_id,
            ProjectMember.user_id == current_user.id,
            ProjectMember.role.in_(["owner", "manager"])
        ).first()
        if not member:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Not enough permissions to create tasks in this project"
            )
    
    db_task = Task(**task_data.dict())
    db.add(db_task)
    db.commit()
    db.refresh(db_task)
    return db_task


@router.get("/", response_model=List[TaskResponse])
def get_tasks(
    project_id: int = None,
    assigned_to: int = None,
    status: str = None,
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Get tasks with optional filters."""
    query = db.query(Task)
    
    # Apply filters
    if project_id:
        # Check if user has access to this project
        if current_user.role != UserRole.ADMIN:
            member = db.query(ProjectMember).filter(
                ProjectMember.project_id == project_id,
                ProjectMember.user_id == current_user.id
            ).first()
            if not member:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Access denied to this project"
                )
        query = query.filter(Task.project_id == project_id)
    
    if assigned_to:
        if current_user.role != UserRole.ADMIN and current_user.id != assigned_to:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Can only view own assigned tasks"
            )
        query = query.filter(Task.assigned_user_id == assigned_to)
    
    if status:
        query = query.filter(Task.status == status)
    
    # If no specific filters, show tasks from projects user has access to
    if not project_id and not assigned_to:
        if current_user.role != UserRole.ADMIN:
            accessible_projects = db.query(ProjectMember.project_id).filter(
                ProjectMember.user_id == current_user.id
            ).subquery()
            query = query.filter(Task.project_id.in_(accessible_projects))
    
    tasks = query.offset(skip).limit(limit).all()
    return tasks


@router.get("/{task_id}", response_model=TaskWithDetails)
def get_task(
    task_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Get task by ID with details."""
    task = db.query(Task).filter(Task.id == task_id).first()
    if not task:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Task not found"
        )
    
    # Check if user has access to this task's project
    if current_user.role != UserRole.ADMIN:
        member = db.query(ProjectMember).filter(
            ProjectMember.project_id == task.project_id,
            ProjectMember.user_id == current_user.id
        ).first()
        if not member:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access denied to this task"
            )
    
    return task


@router.put("/{task_id}", response_model=TaskResponse)
def update_task(
    task_id: int,
    task_update: TaskUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Update task."""
    task = db.query(Task).filter(Task.id == task_id).first()
    if not task:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Task not found"
        )
    
    # Check permissions
    can_update = False
    if current_user.role == UserRole.ADMIN:
        can_update = True
    elif task.assigned_user_id == current_user.id:
        can_update = True  # Assigned user can update their own tasks
    else:
        # Check if user is project manager/owner
        project = db.query(Project).filter(Project.id == task.project_id).first()
        if project and project.owner_id == current_user.id:
            can_update = True
        else:
            member = db.query(ProjectMember).filter(
                ProjectMember.project_id == task.project_id,
                ProjectMember.user_id == current_user.id,
                ProjectMember.role.in_(["owner", "manager"])
            ).first()
            if member:
                can_update = True
    
    if not can_update:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions to update this task"
        )
    
    # Update fields
    update_data = task_update.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(task, field, value)
    
    db.commit()
    db.refresh(task)
    return task


@router.delete("/{task_id}")
def delete_task(
    task_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Delete task."""
    task = db.query(Task).filter(Task.id == task_id).first()
    if not task:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Task not found"
        )
    
    # Check permissions (only admin, project owner, or project manager can delete)
    can_delete = False
    if current_user.role == UserRole.ADMIN:
        can_delete = True
    else:
        project = db.query(Project).filter(Project.id == task.project_id).first()
        if project and project.owner_id == current_user.id:
            can_delete = True
        else:
            member = db.query(ProjectMember).filter(
                ProjectMember.project_id == task.project_id,
                ProjectMember.user_id == current_user.id,
                ProjectMember.role.in_(["owner", "manager"])
            ).first()
            if member:
                can_delete = True
    
    if not can_delete:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions to delete this task"
        )
    
    db.delete(task)
    db.commit()
    return {"message": "Task deleted successfully"}


@router.post("/{task_id}/comments", response_model=CommentResponse)
def add_comment(
    task_id: int,
    comment_data: CommentCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Add comment to task."""
    task = db.query(Task).filter(Task.id == task_id).first()
    if not task:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Task not found"
        )
    
    # Check if user has access to this task's project
    if current_user.role != UserRole.ADMIN:
        member = db.query(ProjectMember).filter(
            ProjectMember.project_id == task.project_id,
            ProjectMember.user_id == current_user.id
        ).first()
        if not member:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access denied to this task"
            )
    
    comment = Comment(
        content=comment_data.content,
        task_id=task_id,
        user_id=current_user.id
    )
    db.add(comment)
    db.commit()
    db.refresh(comment)
    return comment


@router.get("/{task_id}/comments", response_model=List[CommentResponse])
def get_task_comments(
    task_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Get comments for a task."""
    task = db.query(Task).filter(Task.id == task_id).first()
    if not task:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Task not found"
        )
    
    # Check if user has access to this task's project
    if current_user.role != UserRole.ADMIN:
        member = db.query(ProjectMember).filter(
            ProjectMember.project_id == task.project_id,
            ProjectMember.user_id == current_user.id
        ).first()
        if not member:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access denied to this task"
            )
    
    comments = db.query(Comment).filter(Comment.task_id == task_id).all()
    return comments


@router.get("/dashboard/stats", response_model=DashboardStats)
def get_dashboard_stats(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Get dashboard statistics."""
    # Get accessible project IDs
    if current_user.role == UserRole.ADMIN:
        accessible_projects = db.query(Project.id).subquery()
    else:
        accessible_projects = db.query(ProjectMember.project_id).filter(
            ProjectMember.user_id == current_user.id
        ).subquery()
    
    # Task statistics
    total_tasks = db.query(Task).filter(Task.project_id.in_(accessible_projects)).count()
    todo_tasks = db.query(Task).filter(
        and_(Task.project_id.in_(accessible_projects), Task.status == "todo")
    ).count()
    in_progress_tasks = db.query(Task).filter(
        and_(Task.project_id.in_(accessible_projects), Task.status == "in_progress")
    ).count()
    done_tasks = db.query(Task).filter(
        and_(Task.project_id.in_(accessible_projects), Task.status == "done")
    ).count()
    
    # Overdue tasks
    overdue_tasks = db.query(Task).filter(
        and_(
            Task.project_id.in_(accessible_projects),
            Task.deadline < func.now(),
            Task.status != "done"
        )
    ).count()
    
    # Project statistics
    total_projects = db.query(Project).filter(Project.id.in_(accessible_projects)).count()
    active_projects = db.query(Project).filter(
        and_(
            Project.id.in_(accessible_projects),
            Project.status.in_(["planning", "in_progress"])
        )
    ).count()
    
    return DashboardStats(
        total_tasks=total_tasks,
        todo_tasks=todo_tasks,
        in_progress_tasks=in_progress_tasks,
        done_tasks=done_tasks,
        overdue_tasks=overdue_tasks,
        total_projects=total_projects,
        active_projects=active_projects
    )
