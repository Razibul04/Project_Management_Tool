from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from sqlalchemy import func, and_, or_
from typing import List, Optional
from datetime import datetime, timedelta
from ..database import get_db
from ..models.user import User
from ..models.task import Task
from ..models.time_tracking import TimeEntry, TimeEstimate
from ..models.project import ProjectMember
from ..schemas.time_tracking_schema import (
    TimeEntryCreate, TimeEntryUpdate, TimeEntryResponse,
    TimeEstimateCreate, TimeEstimateUpdate, TimeEstimateResponse,
    TimeTrackingStats, StartTimeTrackingRequest, StopTimeTrackingRequest
)
from ..routes.auth import get_current_user

router = APIRouter(prefix="/time-tracking", tags=["time-tracking"])


@router.post("/start", response_model=TimeEntryResponse)
def start_time_tracking(
    request: StartTimeTrackingRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Start time tracking for a task."""
    # Check if task exists and user has access
    task = db.query(Task).filter(Task.id ==request.task_id).first()
    if not task:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Task not found"
        )
    
    # Check if user has access to the task
    if current_user.role.value != "admin":
        if task.assigned_user_id != current_user.id:
            # Check if user is project member
            member = db.query(ProjectMember).filter(
                ProjectMember.project_id == task.project_id,
                ProjectMember.user_id == current_user.id
            ).first()
            if not member:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Access denied to this task"
                )
    
    # Check if user already has a running time entry
    running_entry = db.query(TimeEntry).filter(
        and_(
            TimeEntry.user_id == current_user.id,
            TimeEntry.is_running == "true"
        )
    ).first()
    
    if running_entry:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="You already have a running time entry. Stop it first."
        )
    
    # Create new time entry
    time_entry = TimeEntry(
        task_id=request.task_id,
        user_id=current_user.id,
        description=request.description,
        start_time=datetime.utcnow(),
        is_running="true"
    )
    
    db.add(time_entry)
    db.commit()
    db.refresh(time_entry)
    
    return time_entry


@router.post("/stop", response_model=TimeEntryResponse)
def stop_time_tracking(
    request: StopTimeTrackingRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Stop time tracking for a time entry."""
    time_entry = db.query(TimeEntry).filter(
        and_(
            TimeEntry.id == request.time_entry_id,
            TimeEntry.user_id == current_user.id,
            TimeEntry.is_running == "true"
        )
    ).first()
    
    if not time_entry:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Running time entry not found"
        )
    
    # Calculate duration
    end_time = datetime.utcnow()
    duration = (end_time - time_entry.start_time).total_seconds() / 60  # in minutes
    
    # Update time entry
    time_entry.end_time = end_time
    time_entry.duration_minutes = duration
    time_entry.is_running = "false"
    if request.description:
        time_entry.description = request.description
    
    db.commit()
    db.refresh(time_entry)
    
    return time_entry


@router.get("/entries", response_model=List[TimeEntryResponse])
def get_time_entries(
    task_id: Optional[int] = None,
    user_id: Optional[int] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Get time entries with filtering."""
    query = db.query(TimeEntry)
    
    # Apply access control
    if current_user.role.value != "admin":
        if user_id and user_id != current_user.id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Can only view own time entries"
            )
        query = query.filter(TimeEntry.user_id == current_user.id)
    elif user_id:
        query = query.filter(TimeEntry.user_id == user_id)
    
    # Apply filters
    if task_id:
        query = query.filter(TimeEntry.task_id == task_id)
    
    if start_date:
        query = query.filter(TimeEntry.start_time >= start_date)
    
    if end_date:
        query = query.filter(TimeEntry.start_time <= end_date)
    
    entries = query.offset(skip).limit(limit).all()
    return entries


@router.get("/entries/{entry_id}", response_model=TimeEntryResponse)
def get_time_entry(
    entry_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Get a specific time entry."""
    time_entry = db.query(TimeEntry).filter(TimeEntry.id == entry_id).first()
    if not time_entry:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Time entry not found"
        )
    
    # Check access
    if current_user.role.value != "admin" and time_entry.user_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied to this time entry"
        )
    
    return time_entry


@router.put("/entries/{entry_id}", response_model=TimeEntryResponse)
def update_time_entry(
    entry_id: int,
    update_data: TimeEntryUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Update a time entry."""
    time_entry = db.query(TimeEntry).filter(TimeEntry.id == entry_id).first()
    if not time_entry:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Time entry not found"
        )
    
    # Check access
    if current_user.role.value != "admin" and time_entry.user_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied to this time entry"
        )
    
    # Update fields
    update_dict = update_data.dict(exclude_unset=True)
    for field, value in update_dict.items():
        setattr(time_entry, field, value)
    
    db.commit()
    db.refresh(time_entry)
    
    return time_entry


@router.delete("/entries/{entry_id}")
def delete_time_entry(
    entry_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Delete a time entry."""
    time_entry = db.query(TimeEntry).filter(TimeEntry.id == entry_id).first()
    if not time_entry:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Time entry not found"
        )
    
    # Check access
    if current_user.role.value != "admin" and time_entry.user_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied to this time entry"
        )
    
    db.delete(time_entry)
    db.commit()
    
    return {"message": "Time entry deleted successfully"}


@router.post("/estimates", response_model=TimeEstimateResponse)
def create_time_estimate(
    estimate_data: TimeEstimateCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Create a time estimate for a task."""
    # Check if task exists and user has access
    task = db.query(Task).filter(Task.id == estimate_data.task_id).first()
    if not task:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Task not found"
        )
    
    # Check if user has access to the task
    if current_user.role.value != "admin":
        if task.assigned_user_id != current_user.id:
            # Check if user is project member
            member = db.query(ProjectMember).filter(
                ProjectMember.project_id == task.project_id,
                ProjectMember.user_id == current_user.id
            ).first()
            if not member:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Access denied to this task"
                )
    
    # Check if estimate already exists for this user and task
    existing_estimate = db.query(TimeEstimate).filter(
        and_(
            TimeEstimate.task_id == estimate_data.task_id,
            TimeEstimate.user_id == current_user.id
        )
    ).first()
    
    if existing_estimate:
        # Update existing estimate
        existing_estimate.estimated_hours = estimate_data.estimated_hours
        existing_estimate.estimated_minutes = estimate_data.estimated_minutes
        db.commit()
        db.refresh(existing_estimate)
        return existing_estimate
    else:
        # Create new estimate
        time_estimate = TimeEstimate(
            task_id=estimate_data.task_id,
            user_id=current_user.id,
            estimated_hours=estimate_data.estimated_hours,
            estimated_minutes=estimate_data.estimated_minutes
        )
        
        db.add(time_estimate)
        db.commit()
        db.refresh(time_estimate)
        
        return time_estimate


@router.get("/estimates", response_model=List[TimeEstimateResponse])
def get_time_estimates(
    task_id: Optional[int] = None,
    user_id: Optional[int] = None,
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Get time estimates with filtering."""
    query = db.query(TimeEstimate)
    
    # Apply access control
    if current_user.role.value != "admin":
        if user_id and user_id != current_user.id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Can only view own time estimates"
            )
        query = query.filter(TimeEstimate.user_id == current_user.id)
    elif user_id:
        query = query.filter(TimeEstimate.user_id == user_id)
    
    # Apply filters
    if task_id:
        query = query.filter(TimeEstimate.task_id == task_id)
    
    estimates = query.offset(skip).limit(limit).all()
    return estimates


@router.get("/stats", response_model=TimeTrackingStats)
def get_time_tracking_stats(
    user_id: Optional[int] = None,
    task_id: Optional[int] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Get time tracking statistics."""
    # Determine target user
    target_user_id = user_id if current_user.role.value == "admin" and user_id else current_user.id
    
    # Base query for time entries
    time_query = db.query(TimeEntry).filter(TimeEntry.user_id == target_user_id)
    
    # Apply filters
    if task_id:
        time_query = time_query.filter(TimeEntry.task_id == task_id)
    
    if start_date:
        time_query = time_query.filter(TimeEntry.start_time >= start_date)
    
    if end_date:
        time_query = time_query.filter(TimeEntry.start_time <= end_date)
    
    # Calculate statistics
    total_time_logged = db.query(func.sum(TimeEntry.duration_minutes)).filter(
        TimeEntry.user_id == target_user_id,
        TimeEntry.duration_minutes.isnot(None)
    ).scalar() or 0
    
    total_estimated_time = db.query(func.sum(TimeEstimate.estimated_minutes)).filter(
        TimeEstimate.user_id == target_user_id
    ).scalar() or 0
    
    time_efficiency = (total_time_logged / total_estimated_time * 100) if total_estimated_time > 0 else 0
    
    tasks_completed = db.query(Task).filter(
        Task.assigned_user_id == target_user_id,
        Task.status == "done"
    ).count()
    
    average_time_per_task = total_time_logged / tasks_completed if tasks_completed > 0 else 0
    
    # Most productive hour (simplified)
    most_productive_hour = 9  # Default to 9 AM
    
    # Weekly time logged (last 7 days)
    week_ago = datetime.utcnow() - timedelta(days=7)
    weekly_time_logged = db.query(func.sum(TimeEntry.duration_minutes)).filter(
        TimeEntry.user_id == target_user_id,
        TimeEntry.start_time >= week_ago,
        TimeEntry.duration_minutes.isnot(None)
    ).scalar() or 0
    
    # Monthly time logged (last 30 days)
    month_ago = datetime.utcnow() - timedelta(days=30)
    monthly_time_logged = db.query(func.sum(TimeEntry.duration_minutes)).filter(
        TimeEntry.user_id == target_user_id,
        TimeEntry.start_time >= month_ago,
        TimeEntry.duration_minutes.isnot(None)
    ).scalar() or 0
    
    return TimeTrackingStats(
        total_time_logged=total_time_logged,
        total_estimated_time=total_estimated_time,
        time_efficiency=time_efficiency,
        tasks_completed=tasks_completed,
        average_time_per_task=average_time_per_task,
        most_productive_hour=most_productive_hour,
        weekly_time_logged=weekly_time_logged,
        monthly_time_logged=monthly_time_logged
    )


@router.get("/running", response_model=Optional[TimeEntryResponse])
def get_running_time_entry(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Get currently running time entry for the user."""
    running_entry = db.query(TimeEntry).filter(
        and_(
            TimeEntry.user_id == current_user.id,
            TimeEntry.is_running == "true"
        )
    ).first()
    
    return running_entry
