from fastapi import APIRouter, WebSocket, Query, Depends, HTTPException
from ..services.websocket_service import WebSocketService

router = APIRouter(prefix="/ws", tags=["websocket"])


@router.websocket("/connect")
async def websocket_endpoint(websocket: WebSocket, token: str = Query(...)):
    """WebSocket endpoint for real-time updates."""
    await WebSocketService.handle_websocket_connection(websocket, token)
