from pydantic import BaseModel
from typing import Optional
from datetime import datetime


class FileBase(BaseModel):
    filename: str
    original_filename: str
    file_size: int
    mime_type: str


class FileCreate(FileBase):
    project_id: Optional[int] = None
    task_id: Optional[int] = None


class FileResponse(FileBase):
    id: int
    file_path: str
    uploaded_by_id: int
    project_id: Optional[int] = None
    task_id: Optional[int] = None
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class FileUploadResponse(BaseModel):
    message: str
    file: FileResponse
