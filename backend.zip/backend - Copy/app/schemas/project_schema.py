from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime
from ..models.project import ProjectStatus


class ProjectBase(BaseModel):
    title: str
    description: Optional[str] = None
    status: ProjectStatus = ProjectStatus.PLANNING
    deadline: Optional[datetime] = None


class ProjectCreate(ProjectBase):
    pass


class ProjectUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    status: Optional[ProjectStatus] = None
    deadline: Optional[datetime] = None


class ProjectResponse(ProjectBase):
    id: int
    owner_id: int
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class ProjectWithMembers(ProjectResponse):
    members: List[dict] = []


class ProjectMemberCreate(BaseModel):
    user_id: int
    role: str = "member"


class ProjectMemberResponse(BaseModel):
    id: int
    user_id: int
    role: str
    joined_at: datetime
    user: dict

    class Config:
        from_attributes = True
