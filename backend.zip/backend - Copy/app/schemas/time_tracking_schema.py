from pydantic import BaseModel
from typing import Optional
from datetime import datetime


class TimeEntryBase(BaseModel):
    task_id: int
    description: Optional[str] = None
    start_time: datetime
    end_time: Optional[datetime] = None
    duration_minutes: Optional[float] = None


class TimeEntryCreate(TimeEntryBase):
    pass


class TimeEntryUpdate(BaseModel):
    description: Optional[str] = None
    end_time: Optional[datetime] = None
    duration_minutes: Optional[float] = None


class TimeEntryResponse(TimeEntryBase):
    id: int
    user_id: int
    is_running: str
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class TimeEstimateBase(BaseModel):
    task_id: int
    estimated_hours: float
    estimated_minutes: float


class TimeEstimateCreate(TimeEstimateBase):
    pass


class TimeEstimateUpdate(BaseModel):
    estimated_hours: Optional[float] = None
    estimated_minutes: Optional[float] = None


class TimeEstimateResponse(TimeEstimateBase):
    id: int
    user_id: int
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class TimeTrackingStats(BaseModel):
    total_time_logged: float  # in minutes
    total_estimated_time: float  # in minutes
    time_efficiency: float  # percentage
    tasks_completed: int
    average_time_per_task: float  # in minutes
    most_productive_hour: int  # 0-23
    weekly_time_logged: float  # in minutes
    monthly_time_logged: float  # in minutes


class StartTimeTrackingRequest(BaseModel):
    task_id: int
    description: Optional[str] = None


class StopTimeTrackingRequest(BaseModel):
    time_entry_id: int
    description: Optional[str] = None
