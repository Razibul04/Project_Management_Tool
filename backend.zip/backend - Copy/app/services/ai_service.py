from typing import List, Optional
import openai
import groq
from ..config import settings


class AIService:
    def __init__(self):
        if settings.openai_api_key:
            openai.api_key = settings.openai_api_key
        if settings.groq_api_key:
            self.groq_client = groq.Groq(api_key=settings.groq_api_key)
        else:
            self.groq_client = None

    def generate_user_stories(self, project_description: str, num_stories: int = 5) -> List[str]:
        """Generate user stories for a project using AI."""
        if not self.groq_client:
            raise ValueError("GROQ API key not configured")
        
        prompt = f"""
        Based on the following project description, generate {num_stories} user stories in the format:
        "As a [role], I want to [action], so that [benefit]."

        Project Description: {project_description}

        Please generate diverse user stories covering different user roles and functionalities.
        Each story should be specific, actionable, and valuable.
        """
        
        try:
            response = self.groq_client.chat.completions.create(
                model="llama3-8b-8192",
                messages=[
                    {
                        "role": "system",
                        "content": "You are a product manager expert at writing user stories. Generate clear, actionable user stories following the standard format."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                max_tokens=1000,
                temperature=0.7
            )
            
            stories_text = response.choices[0].message.content
            # Parse the stories from the response
            stories = []
            for line in stories_text.split('\n'):
                line = line.strip()
                if line.startswith('As a ') and 'so that' in line:
                    stories.append(line)
            
            return stories[:num_stories]
            
        except Exception as e:
            raise Exception(f"Failed to generate user stories: {str(e)}")

    def generate_tasks_from_stories(self, user_stories: List[str]) -> List[dict]:
        """Generate tasks from user stories."""
        if not self.groq_client:
            raise ValueError("GROQ API key not configured")
        
        stories_text = "\n".join([f"- {story}" for story in user_stories])
        prompt = f"""
        Based on the following user stories, generate specific development tasks.
        For each user story, create 2-3 concrete tasks that would be needed to implement it.
        
        User Stories:
        {stories_text}
        
        Format each task as: "Task: [task description] | Priority: [low/medium/high] | Estimated Hours: [number]"
        """
        
        try:
            response = self.groq_client.chat.completions.create(
                model="llama3-8b-8192",
                messages=[
                    {
                        "role": "system",
                        "content": "You are a technical project manager. Break down user stories into specific, actionable development tasks."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                max_tokens=1500,
                temperature=0.7
            )
            
            tasks_text = response.choices[0].message.content
            tasks = []
            
            for line in tasks_text.split('\n'):
                line = line.strip()
                if line.startswith('Task:'):
                    # Parse task information
                    parts = line.split('|')
                    if len(parts) >= 3:
                        task_desc = parts[0].replace('Task:', '').strip()
                        priority = parts[1].replace('Priority:', '').strip().lower()
                        hours = parts[2].replace('Estimated Hours:', '').strip()
                        
                        tasks.append({
                            "title": task_desc,
                            "priority": priority if priority in ['low', 'medium', 'high', 'urgent'] else 'medium',
                            "estimated_hours": int(hours) if hours.isdigit() else 8
                        })
            
            return tasks
            
        except Exception as e:
            raise Exception(f"Failed to generate tasks: {str(e)}")


def get_ai_service() -> AIService:
    """Get AI service instance."""
    return AIService()
