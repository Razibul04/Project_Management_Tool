import json
import logging
from typing import Any, Optional, Union
from datetime import datetime, timedelta
import redis
from ..config import settings

logger = logging.getLogger(__name__)


class CacheService:
    def __init__(self):
        try:
            self.redis_client = redis.from_url(settings.redis_url, decode_responses=True)
            self.redis_client.ping()  # Test connection
            self.connected = True
        except Exception as e:
            logger.warning(f"Redis connection failed: {e}. Using in-memory cache.")
            self.redis_client = None
            self.connected = False
            self._memory_cache = {}

    def _get_key(self, prefix: str, key: str) -> str:
        """Generate a cache key."""
        return f"{prefix}:{key}"

    def get(self, prefix: str, key: str) -> Optional[Any]:
        """Get a value from cache."""
        cache_key = self._get_key(prefix, key)
        
        try:
            if self.connected and self.redis_client:
                value = self.redis_client.get(cache_key)
                return json.loads(value) if value else None
            else:
                # Fallback to memory cache
                cached_item = self._memory_cache.get(cache_key)
                if cached_item and cached_item['expires'] > datetime.utcnow():
                    return cached_item['value']
                elif cached_item:
                    # Expired, remove it
                    del self._memory_cache[cache_key]
                return None
        except Exception as e:
            logger.error(f"Cache get error: {e}")
            return None

    def set(self, prefix: str, key: str, value: Any, ttl: int = 3600) -> bool:
        """Set a value in cache with TTL."""
        cache_key = self._get_key(prefix, key)
        
        try:
            if self.connected and self.redis_client:
                return self.redis_client.setex(cache_key, ttl, json.dumps(value))
            else:
                # Fallback to memory cache
                self._memory_cache[cache_key] = {
                    'value': value,
                    'expires': datetime.utcnow() + timedelta(seconds=ttl)
                }
                return True
        except Exception as e:
            logger.error(f"Cache set error: {e}")
            return False

    def delete(self, prefix: str, key: str) -> bool:
        """Delete a value from cache."""
        cache_key = self._get_key(prefix, key)
        
        try:
            if self.connected and self.redis_client:
                return bool(self.redis_client.delete(cache_key))
            else:
                # Fallback to memory cache
                if cache_key in self._memory_cache:
                    del self._memory_cache[cache_key]
                    return True
                return False
        except Exception as e:
            logger.error(f"Cache delete error: {e}")
            return False

    def delete_pattern(self, prefix: str, pattern: str) -> int:
        """Delete all keys matching a pattern."""
        try:
            if self.connected and self.redis_client:
                keys = self.redis_client.keys(f"{prefix}:{pattern}")
                if keys:
                    return self.redis_client.delete(*keys)
                return 0
            else:
                # Fallback to memory cache
                deleted_count = 0
                pattern_key = f"{prefix}:{pattern}"
                keys_to_delete = [k for k in self._memory_cache.keys() if k.startswith(pattern_key)]
                for key in keys_to_delete:
                    del self._memory_cache[key]
                    deleted_count += 1
                return deleted_count
        except Exception as e:
            logger.error(f"Cache delete pattern error: {e}")
            return 0

    def exists(self, prefix: str, key: str) -> bool:
        """Check if a key exists in cache."""
        cache_key = self._get_key(prefix, key)
        
        try:
            if self.connected and self.redis_client:
                return bool(self.redis_client.exists(cache_key))
            else:
                # Fallback to memory cache
                cached_item = self._memory_cache.get(cache_key)
                if cached_item and cached_item['expires'] > datetime.utcnow():
                    return True
                elif cached_item:
                    # Expired, remove it
                    del self._memory_cache[cache_key]
                return False
        except Exception as e:
            logger.error(f"Cache exists error: {e}")
            return False

    def get_or_set(self, prefix: str, key: str, func, ttl: int = 3600) -> Any:
        """Get value from cache or set it using a function."""
        cached_value = self.get(prefix, key)
        if cached_value is not None:
            return cached_value
        
        # Value not in cache, compute it
        value = func()
        self.set(prefix, key, value, ttl)
        return value

    def invalidate_user_cache(self, user_id: int):
        """Invalidate all cache entries for a specific user."""
        patterns = [
            f"user:{user_id}:*",
            f"projects:user:{user_id}:*",
            f"tasks:user:{user_id}:*",
            f"dashboard:user:{user_id}:*"
        ]
        
        for pattern in patterns:
            self.delete_pattern("", pattern)

    def invalidate_project_cache(self, project_id: int):
        """Invalidate all cache entries for a specific project."""
        patterns = [
            f"project:{project_id}:*",
            f"tasks:project:{project_id}:*",
            f"members:project:{project_id}:*"
        ]
        
        for pattern in patterns:
            self.delete_pattern("", pattern)

    def invalidate_task_cache(self, task_id: int):
        """Invalidate all cache entries for a specific task."""
        patterns = [
            f"task:{task_id}:*",
            f"comments:task:{task_id}:*",
            f"files:task:{task_id}:*"
        ]
        
        for pattern in patterns:
            self.delete_pattern("", pattern)


# Global cache service instance
cache_service = CacheService()


def get_cache_service() -> CacheService:
    """Get cache service instance."""
    return cache_service
