import logging
from typing import List, Optional, Dict, Any
from fastapi_mail import FastMail, MessageSchema, ConnectionConfig
from jinja2 import Template
from ..config import settings

logger = logging.getLogger(__name__)


class EmailService:
    def __init__(self):
        self.config = ConnectionConfig(
            MAIL_USERNAME=settings.smtp_username,
            MAIL_PASSWORD=settings.smtp_password,
            MAIL_FROM=settings.smtp_username,
            MAIL_PORT=settings.smtp_port,
            MAIL_SERVER=settings.smtp_server,
            MAIL_TLS=settings.smtp_use_tls,
            MAIL_SSL=False,
            USE_CREDENTIALS=True,
            VALIDATE_CERTS=True
        )
        self.fastmail = FastMail(self.config)

    async def send_email(
        self,
        to: List[str],
        subject: str,
        template: str,
        context: Dict[str, Any] = None
    ) -> bool:
        """Send an email using a template."""
        try:
            if not settings.smtp_server:
                logger.warning("SMTP not configured, skipping email send")
                return False

            # Render template
            template_obj = Template(template)
            html_content = template_obj.render(**(context or {}))

            message = MessageSchema(
                subject=subject,
                recipients=to,
                body=html_content,
                subtype="html"
            )

            await self.fastmail.send_message(message)
            logger.info(f"Email sent successfully to {to}")
            return True

        except Exception as e:
            logger.error(f"Failed to send email to {to}: {e}")
            return False

    async def send_task_assignment_notification(
        self,
        assignee_email: str,
        task_title: str,
        project_title: str,
        assigner_name: str,
        task_url: str
    ) -> bool:
        """Send notification when a task is assigned."""
        template = """
        <html>
        <body>
            <h2>New Task Assignment</h2>
            <p>Hello,</p>
            <p>You have been assigned a new task:</p>
            <ul>
                <li><strong>Task:</strong> {{ task_title }}</li>
                <li><strong>Project:</strong> {{ project_title }}</li>
                <li><strong>Assigned by:</strong> {{ assigner_name }}</li>
            </ul>
            <p><a href="{{ task_url }}">View Task</a></p>
            <p>Best regards,<br>Project Management Team</p>
        </body>
        </html>
        """
        
        return await self.send_email(
            to=[assignee_email],
            subject=f"New Task Assignment: {task_title}",
            template=template,
            context={
                "task_title": task_title,
                "project_title": project_title,
                "assigner_name": assigner_name,
                "task_url": task_url
            }
        )

    async def send_task_update_notification(
        self,
        user_email: str,
        task_title: str,
        project_title: str,
        update_type: str,
        updated_by: str,
        task_url: str
    ) -> bool:
        """Send notification when a task is updated."""
        template = """
        <html>
        <body>
            <h2>Task Updated</h2>
            <p>Hello,</p>
            <p>A task you're involved with has been updated:</p>
            <ul>
                <li><strong>Task:</strong> {{ task_title }}</li>
                <li><strong>Project:</strong> {{ project_title }}</li>
                <li><strong>Update:</strong> {{ update_type }}</li>
                <li><strong>Updated by:</strong> {{ updated_by }}</li>
            </ul>
            <p><a href="{{ task_url }}">View Task</a></p>
            <p>Best regards,<br>Project Management Team</p>
        </body>
        </html>
        """
        
        return await self.send_email(
            to=[user_email],
            subject=f"Task Updated: {task_title}",
            template=template,
            context={
                "task_title": task_title,
                "project_title": project_title,
                "update_type": update_type,
                "updated_by": updated_by,
                "task_url": task_url
            }
        )

    async def send_project_invitation(
        self,
        user_email: str,
        project_title: str,
        inviter_name: str,
        project_url: str
    ) -> bool:
        """Send project invitation email."""
        template = """
        <html>
        <body>
            <h2>Project Invitation</h2>
            <p>Hello,</p>
            <p>You have been invited to join a project:</p>
            <ul>
                <li><strong>Project:</strong> {{ project_title }}</li>
                <li><strong>Invited by:</strong> {{ inviter_name }}</li>
            </ul>
            <p><a href="{{ project_url }}">View Project</a></p>
            <p>Best regards,<br>Project Management Team</p>
        </body>
        </html>
        """
        
        return await self.send_email(
            to=[user_email],
            subject=f"Project Invitation: {project_title}",
            template=template,
            context={
                "project_title": project_title,
                "inviter_name": inviter_name,
                "project_url": project_url
            }
        )

    async def send_daily_digest(
        self,
        user_email: str,
        user_name: str,
        tasks_due_today: List[Dict],
        overdue_tasks: List[Dict],
        recent_activity: List[Dict]
    ) -> bool:
        """Send daily digest email."""
        template = """
        <html>
        <body>
            <h2>Daily Project Management Digest</h2>
            <p>Hello {{ user_name }},</p>
            
            {% if tasks_due_today %}
            <h3>Tasks Due Today</h3>
            <ul>
                {% for task in tasks_due_today %}
                <li>{{ task.title }} ({{ task.project_title }})</li>
                {% endfor %}
            </ul>
            {% endif %}
            
            {% if overdue_tasks %}
            <h3>Overdue Tasks</h3>
            <ul>
                {% for task in overdue_tasks %}
                <li>{{ task.title }} ({{ task.project_title }}) - {{ task.days_overdue }} days overdue</li>
                {% endfor %}
            </ul>
            {% endif %}
            
            {% if recent_activity %}
            <h3>Recent Activity</h3>
            <ul>
                {% for activity in recent_activity %}
                <li>{{ activity.description }}</li>
                {% endfor %}
            </ul>
            {% endif %}
            
            <p>Best regards,<br>Project Management Team</p>
        </body>
        </html>
        """
        
        return await self.send_email(
            to=[user_email],
            subject="Daily Project Management Digest",
            template=template,
            context={
                "user_name": user_name,
                "tasks_due_today": tasks_due_today,
                "overdue_tasks": overdue_tasks,
                "recent_activity": recent_activity
            }
        )

    async def send_welcome_email(
        self,
        user_email: str,
        user_name: str,
        login_url: str
    ) -> bool:
        """Send welcome email to new users."""
        template = """
        <html>
        <body>
            <h2>Welcome to Project Management Tool</h2>
            <p>Hello {{ user_name }},</p>
            <p>Welcome to our project management platform! Your account has been created successfully.</p>
            <p>You can now:</p>
            <ul>
                <li>Create and manage projects</li>
                <li>Assign and track tasks</li>
                <li>Collaborate with your team</li>
                <li>Monitor project progress</li>
            </ul>
            <p><a href="{{ login_url }}">Get Started</a></p>
            <p>Best regards,<br>Project Management Team</p>
        </body>
        </html>
        """
        
        return await self.send_email(
            to=[user_email],
            subject="Welcome to Project Management Tool",
            template=template,
            context={
                "user_name": user_name,
                "login_url": login_url
            }
        )


# Global email service instance
email_service = EmailService()
