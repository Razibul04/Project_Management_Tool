import logging
import time
import psutil
import os
from typing import Dict, Any, Optional
from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from sqlalchemy import text
from ..database import get_db
from ..services.cache_service import get_cache_service

logger = logging.getLogger(__name__)


class MonitoringService:
    def __init__(self):
        self.cache_service = get_cache_service()
        self.start_time = time.time()

    def get_system_metrics(self) -> Dict[str, Any]:
        """Get system performance metrics."""
        try:
            # CPU usage
            cpu_percent = psutil.cpu_percent(interval=1)
            cpu_count = psutil.cpu_count()
            
            # Memory usage
            memory = psutil.virtual_memory()
            memory_percent = memory.percent
            memory_available = memory.available
            memory_total = memory.total
            
            # Disk usage
            disk = psutil.disk_usage('/')
            disk_percent = disk.percent
            disk_free = disk.free
            disk_total = disk.total
            
            # Process info
            process = psutil.Process(os.getpid())
            process_memory = process.memory_info().rss
            process_cpu = process.cpu_percent()
            
            return {
                "cpu": {
                    "percent": cpu_percent,
                    "count": cpu_count
                },
                "memory": {
                    "percent": memory_percent,
                    "available_bytes": memory_available,
                    "total_bytes": memory_total,
                    "available_gb": round(memory_available / (1024**3), 2),
                    "total_gb": round(memory_total / (1024**3), 2)
                },
                "disk": {
                    "percent": disk_percent,
                    "free_bytes": disk_free,
                    "total_bytes": disk_total,
                    "free_gb": round(disk_free / (1024**3), 2),
                    "total_gb": round(disk_total / (1024**3), 2)
                },
                "process": {
                    "memory_bytes": process_memory,
                    "memory_mb": round(process_memory / (1024**2), 2),
                    "cpu_percent": process_cpu
                },
                "uptime_seconds": time.time() - self.start_time,
                "uptime_hours": round((time.time() - self.start_time) / 3600, 2)
            }
        except Exception as e:
            logger.error(f"Error getting system metrics: {e}")
            return {}

    def get_database_metrics(self, db: Session) -> Dict[str, Any]:
        """Get database performance metrics."""
        try:
            # Database connection count
            connection_count = db.execute(text("SELECT count(*) FROM pg_stat_activity")).scalar()
            
            # Database size
            db_size = db.execute(text("SELECT pg_database_size(current_database())")).scalar()
            
            # Table sizes
            table_sizes = db.execute(text("""
                SELECT 
                    schemaname,
                    tablename,
                    pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename)) as size
                FROM pg_tables 
                WHERE schemaname = 'public'
                ORDER BY pg_total_relation_size(schemaname||'.'||tablename) DESC
                LIMIT 10
            """)).fetchall()
            
            # Slow queries (if available)
            slow_queries = db.execute(text("""
                SELECT query, mean_time, calls
                FROM pg_stat_statements 
                ORDER BY mean_time DESC 
                LIMIT 5
            """)).fetchall()
            
            return {
                "connection_count": connection_count,
                "database_size_bytes": db_size,
                "database_size_mb": round(db_size / (1024**2), 2),
                "table_sizes": [
                    {
                        "schema": row[0],
                        "table": row[1],
                        "size": row[2]
                    }
                    for row in table_sizes
                ],
                "slow_queries": [
                    {
                        "query": row[0][:100] + "..." if len(row[0]) > 100 else row[0],
                        "mean_time": row[1],
                        "calls": row[2]
                    }
                    for row in slow_queries
                ]
            }
        except Exception as e:
            logger.error(f"Error getting database metrics: {e}")
            return {}

    def get_application_metrics(self) -> Dict[str, Any]:
        """Get application-specific metrics."""
        try:
            # Cache metrics
            cache_metrics = self._get_cache_metrics()
            
            # API metrics (would need to be tracked separately)
            api_metrics = self._get_api_metrics()
            
            return {
                "cache": cache_metrics,
                "api": api_metrics,
                "timestamp": datetime.utcnow().isoformat()
            }
        except Exception as e:
            logger.error(f"Error getting application metrics: {e}")
            return {}

    def _get_cache_metrics(self) -> Dict[str, Any]:
        """Get cache performance metrics."""
        try:
            if self.cache_service.connected:
                # Redis metrics
                info = self.cache_service.redis_client.info()
                return {
                    "connected": True,
                    "used_memory": info.get("used_memory", 0),
                    "used_memory_human": info.get("used_memory_human", "0B"),
                    "connected_clients": info.get("connected_clients", 0),
                    "total_commands_processed": info.get("total_commands_processed", 0),
                    "keyspace_hits": info.get("keyspace_hits", 0),
                    "keyspace_misses": info.get("keyspace_misses", 0),
                    "hit_rate": self._calculate_hit_rate(
                        info.get("keyspace_hits", 0),
                        info.get("keyspace_misses", 0)
                    )
                }
            else:
                # Memory cache metrics
                return {
                    "connected": False,
                    "memory_cache_size": len(self.cache_service._memory_cache),
                    "type": "memory"
                }
        except Exception as e:
            logger.error(f"Error getting cache metrics: {e}")
            return {"connected": False, "error": str(e)}

    def _get_api_metrics(self) -> Dict[str, Any]:
        """Get API performance metrics."""
        # This would typically be tracked in a separate metrics store
        # For now, return basic structure
        return {
            "total_requests": 0,  # Would be tracked in production
            "requests_per_minute": 0,
            "average_response_time": 0,
            "error_rate": 0
        }

    def _calculate_hit_rate(self, hits: int, misses: int) -> float:
        """Calculate cache hit rate."""
        total = hits + misses
        return (hits / total * 100) if total > 0 else 0

    def get_health_status(self, db: Session) -> Dict[str, Any]:
        """Get overall health status of the application."""
        try:
            # Check database connectivity
            db.execute(text("SELECT 1"))
            db_healthy = True
        except Exception as e:
            logger.error(f"Database health check failed: {e}")
            db_healthy = False

        # Check cache connectivity
        cache_healthy = self.cache_service.connected

        # Get system metrics
        system_metrics = self.get_system_metrics()
        
        # Determine overall health
        overall_healthy = db_healthy and cache_healthy

        return {
            "status": "healthy" if overall_healthy else "unhealthy",
            "database": "healthy" if db_healthy else "unhealthy",
            "cache": "healthy" if cache_healthy else "unhealthy",
            "system": system_metrics,
            "timestamp": datetime.utcnow().isoformat()
        }

    def log_performance_metrics(self, operation: str, duration: float, **kwargs):
        """Log performance metrics for an operation."""
        logger.info(
            f"Performance metric: {operation}",
            extra={
                "operation": operation,
                "duration_seconds": duration,
                "timestamp": datetime.utcnow().isoformat(),
                **kwargs
            }
        )

    def track_api_call(self, endpoint: str, method: str, status_code: int, duration: float):
        """Track API call metrics."""
        # In production, this would be sent to a metrics service like Prometheus
        logger.info(
            f"API call tracked",
            extra={
                "endpoint": endpoint,
                "method": method,
                "status_code": status_code,
                "duration_seconds": duration,
                "timestamp": datetime.utcnow().isoformat()
            }
        )


# Global monitoring service instance
monitoring_service = MonitoringService()


def get_monitoring_service() -> MonitoringService:
    """Get monitoring service instance."""
    return monitoring_service
