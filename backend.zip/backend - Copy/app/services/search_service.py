import logging
from typing import List, Dict, Any, Optional
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, func, text
from ..models.user import User
from ..models.project import Project, ProjectMember
from ..models.task import Task, Comment
from ..models.file import File as FileModel

logger = logging.getLogger(__name__)


class SearchService:
    def __init__(self, db: Session):
        self.db = db

    def search_projects(
        self,
        query: str,
        user_id: int,
        user_role: str,
        status: Optional[str] = None,
        owner_id: Optional[int] = None,
        limit: int = 20,
        offset: int = 0
    ) -> Dict[str, Any]:
        """Search projects with advanced filtering."""
        base_query = self.db.query(Project)
        
        # Apply access control
        if user_role != "admin":
            accessible_projects = self.db.query(ProjectMember.project_id).filter(
                ProjectMember.user_id == user_id
            ).subquery()
            base_query = base_query.filter(
                or_(
                    Project.owner_id == user_id,
                    Project.id.in_(accessible_projects)
                )
            )
        
        # Apply text search
        if query:
            search_filter = or_(
                Project.title.ilike(f"%{query}%"),
                Project.description.ilike(f"%{query}%")
            )
            base_query = base_query.filter(search_filter)
        
        # Apply filters
        if status:
            base_query = base_query.filter(Project.status == status)
        
        if owner_id:
            base_query = base_query.filter(Project.owner_id == owner_id)
        
        # Get total count
        total = base_query.count()
        
        # Apply pagination and get results
        projects = base_query.offset(offset).limit(limit).all()
        
        return {
            "results": projects,
            "total": total,
            "offset": offset,
            "limit": limit
        }

    def search_tasks(
        self,
        query: str,
        user_id: int,
        user_role: str,
        project_id: Optional[int] = None,
        status: Optional[str] = None,
        priority: Optional[str] = None,
        assigned_to: Optional[int] = None,
        due_date_from: Optional[str] = None,
        due_date_to: Optional[str] = None,
        limit: int = 20,
        offset: int = 0
    ) -> Dict[str, Any]:
        """Search tasks with advanced filtering."""
        base_query = self.db.query(Task)
        
        # Apply access control
        if user_role != "admin":
            accessible_projects = self.db.query(ProjectMember.project_id).filter(
                ProjectMember.user_id == user_id
            ).subquery()
            base_query = base_query.filter(
                or_(
                    Task.assigned_user_id == user_id,
                    Task.project_id.in_(accessible_projects)
                )
            )
        
        # Apply text search
        if query:
            search_filter = or_(
                Task.title.ilike(f"%{query}%"),
                Task.description.ilike(f"%{query}%")
            )
            base_query = base_query.filter(search_filter)
        
        # Apply filters
        if project_id:
            base_query = base_query.filter(Task.project_id == project_id)
        
        if status:
            base_query = base_query.filter(Task.status == status)
        
        if priority:
            base_query = base_query.filter(Task.priority == priority)
        
        if assigned_to:
            base_query = base_query.filter(Task.assigned_user_id == assigned_to)
        
        if due_date_from:
            base_query = base_query.filter(Task.deadline >= due_date_from)
        
        if due_date_to:
            base_query = base_query.filter(Task.deadline <= due_date_to)
        
        # Get total count
        total = base_query.count()
        
        # Apply pagination and get results
        tasks = base_query.offset(offset).limit(limit).all()
        
        return {
            "results": tasks,
            "total": total,
            "offset": offset,
            "limit": limit
        }

    def search_users(
        self,
        query: str,
        user_id: int,
        user_role: str,
        role_filter: Optional[str] = None,
        limit: int = 20,
        offset: int = 0
    ) -> Dict[str, Any]:
        """Search users with filtering."""
        base_query = self.db.query(User)
        
        # Apply access control (only admin can search all users)
        if user_role != "admin":
            # Regular users can only see users from their projects
            accessible_users = self.db.query(ProjectMember.user_id).join(Project).filter(
                or_(
                    Project.owner_id == user_id,
                    ProjectMember.user_id == user_id
                )
            ).subquery()
            base_query = base_query.filter(User.id.in_(accessible_users))
        
        # Apply text search
        if query:
            search_filter = or_(
                User.name.ilike(f"%{query}%"),
                User.email.ilike(f"%{query}%")
            )
            base_query = base_query.filter(search_filter)
        
        # Apply role filter
        if role_filter:
            base_query = base_query.filter(User.role == role_filter)
        
        # Get total count
        total = base_query.count()
        
        # Apply pagination and get results
        users = base_query.offset(offset).limit(limit).all()
        
        return {
            "results": users,
            "total": total,
            "offset": offset,
            "limit": limit
        }

    def search_comments(
        self,
        query: str,
        user_id: int,
        user_role: str,
        task_id: Optional[int] = None,
        project_id: Optional[int] = None,
        limit: int = 20,
        offset: int = 0
    ) -> Dict[str, Any]:
        """Search comments with filtering."""
        base_query = self.db.query(Comment).join(Task)
        
        # Apply access control
        if user_role != "admin":
            accessible_projects = self.db.query(ProjectMember.project_id).filter(
                ProjectMember.user_id == user_id
            ).subquery()
            base_query = base_query.filter(
                or_(
                    Comment.user_id == user_id,
                    Task.project_id.in_(accessible_projects)
                )
            )
        
        # Apply text search
        if query:
            base_query = base_query.filter(Comment.content.ilike(f"%{query}%"))
        
        # Apply filters
        if task_id:
            base_query = base_query.filter(Comment.task_id == task_id)
        
        if project_id:
            base_query = base_query.filter(Task.project_id == project_id)
        
        # Get total count
        total = base_query.count()
        
        # Apply pagination and get results
        comments = base_query.offset(offset).limit(limit).all()
        
        return {
            "results": comments,
            "total": total,
            "offset": offset,
            "limit": limit
        }

    def search_files(
        self,
        query: str,
        user_id: int,
        user_role: str,
        project_id: Optional[int] = None,
        task_id: Optional[int] = None,
        file_type: Optional[str] = None,
        limit: int = 20,
        offset: int = 0
    ) -> Dict[str, Any]:
        """Search files with filtering."""
        base_query = self.db.query(FileModel)
        
        # Apply access control
        if user_role != "admin":
            accessible_projects = self.db.query(ProjectMember.project_id).filter(
                ProjectMember.user_id == user_id
            ).subquery()
            base_query = base_query.filter(
                or_(
                    FileModel.uploaded_by_id == user_id,
                    FileModel.project_id.in_(accessible_projects)
                )
            )
        
        # Apply text search
        if query:
            search_filter = or_(
                FileModel.original_filename.ilike(f"%{query}%"),
                FileModel.filename.ilike(f"%{query}%")
            )
            base_query = base_query.filter(search_filter)
        
        # Apply filters
        if project_id:
            base_query = base_query.filter(FileModel.project_id == project_id)
        
        if task_id:
            base_query = base_query.filter(FileModel.task_id == task_id)
        
        if file_type:
            base_query = base_query.filter(FileModel.mime_type.like(f"%{file_type}%"))
        
        # Get total count
        total = base_query.count()
        
        # Apply pagination and get results
        files = base_query.offset(offset).limit(limit).all()
        
        return {
            "results": files,
            "total": total,
            "offset": offset,
            "limit": limit
        }

    def global_search(
        self,
        query: str,
        user_id: int,
        user_role: str,
        search_types: List[str] = None,
        limit: int = 10
    ) -> Dict[str, Any]:
        """Perform global search across all entities."""
        if not search_types:
            search_types = ["projects", "tasks", "users", "comments", "files"]
        
        results = {}
        
        if "projects" in search_types:
            project_results = self.search_projects(query, user_id, user_role, limit=limit)
            results["projects"] = {
                "items": project_results["results"],
                "total": project_results["total"]
            }
        
        if "tasks" in search_types:
            task_results = self.search_tasks(query, user_id, user_role, limit=limit)
            results["tasks"] = {
                "items": task_results["results"],
                "total": task_results["total"]
            }
        
        if "users" in search_types:
            user_results = self.search_users(query, user_id, user_role, limit=limit)
            results["users"] = {
                "items": user_results["results"],
                "total": user_results["total"]
            }
        
        if "comments" in search_types:
            comment_results = self.search_comments(query, user_id, user_role, limit=limit)
            results["comments"] = {
                "items": comment_results["results"],
                "total": comment_results["total"]
            }
        
        if "files" in search_types:
            file_results = self.search_files(query, user_id, user_role, limit=limit)
            results["files"] = {
                "items": file_results["results"],
                "total": file_results["total"]
            }
        
        return results

    def get_search_suggestions(
        self,
        query: str,
        user_id: int,
        user_role: str,
        limit: int = 5
    ) -> List[str]:
        """Get search suggestions based on query."""
        suggestions = []
        
        # Get project titles
        projects = self.db.query(Project.title).filter(
            Project.title.ilike(f"%{query}%")
        ).limit(limit).all()
        
        for project in projects:
            suggestions.append(project.title)
        
        # Get task titles
        tasks = self.db.query(Task.title).filter(
            Task.title.ilike(f"%{query}%")
        ).limit(limit).all()
        
        for task in tasks:
            suggestions.append(task.title)
        
        # Get user names
        users = self.db.query(User.name).filter(
            User.name.ilike(f"%{query}%")
        ).limit(limit).all()
        
        for user in users:
            suggestions.append(user.name)
        
        return list(set(suggestions))[:limit]


def get_search_service(db: Session) -> SearchService:
    """Get search service instance."""
    return SearchService(db)
