import json
import logging
from typing import Dict, List, Set
from fastapi import WebSocket, WebSocketDisconnect
from ..utils.security import verify_token
from ..models.user import User

logger = logging.getLogger(__name__)


class ConnectionManager:
    def __init__(self):
        # Store active connections by user_id
        self.active_connections: Dict[int, List[WebSocket]] = {}
        # Store project subscriptions
        self.project_subscriptions: Dict[int, Set[int]] = {}  # project_id -> set of user_ids
        # Store task subscriptions
        self.task_subscriptions: Dict[int, Set[int]] = {}  # task_id -> set of user_ids

    async def connect(self, websocket: WebSocket, user_id: int):
        """Accept a new WebSocket connection."""
        await websocket.accept()
        
        if user_id not in self.active_connections:
            self.active_connections[user_id] = []
        
        self.active_connections[user_id].append(websocket)
        logger.info(f"User {user_id} connected. Total connections: {len(self.active_connections[user_id])}")

    def disconnect(self, websocket: WebSocket, user_id: int):
        """Remove a WebSocket connection."""
        if user_id in self.active_connections:
            self.active_connections[user_id].remove(websocket)
            if not self.active_connections[user_id]:
                del self.active_connections[user_id]
        
        # Remove from all subscriptions
        self._remove_from_all_subscriptions(user_id)
        logger.info(f"User {user_id} disconnected")

    def _remove_from_all_subscriptions(self, user_id: int):
        """Remove user from all project and task subscriptions."""
        for project_id in self.project_subscriptions:
            self.project_subscriptions[project_id].discard(user_id)
        
        for task_id in self.task_subscriptions:
            self.task_subscriptions[task_id].discard(user_id)

    async def subscribe_to_project(self, user_id: int, project_id: int):
        """Subscribe user to project updates."""
        if project_id not in self.project_subscriptions:
            self.project_subscriptions[project_id] = set()
        
        self.project_subscriptions[project_id].add(user_id)
        logger.info(f"User {user_id} subscribed to project {project_id}")

    async def subscribe_to_task(self, user_id: int, task_id: int):
        """Subscribe user to task updates."""
        if task_id not in self.task_subscriptions:
            self.task_subscriptions[task_id] = set()
        
        self.task_subscriptions[task_id].add(user_id)
        logger.info(f"User {user_id} subscribed to task {task_id}")

    async def send_personal_message(self, message: dict, user_id: int):
        """Send a message to a specific user."""
        if user_id in self.active_connections:
            for connection in self.active_connections[user_id]:
                try:
                    await connection.send_text(json.dumps(message))
                except Exception as e:
                    logger.error(f"Error sending message to user {user_id}: {e}")

    async def broadcast_to_project(self, message: dict, project_id: int):
        """Broadcast a message to all users subscribed to a project."""
        if project_id in self.project_subscriptions:
            for user_id in self.project_subscriptions[project_id]:
                await self.send_personal_message(message, user_id)

    async def broadcast_to_task(self, message: dict, task_id: int):
        """Broadcast a message to all users subscribed to a task."""
        if task_id in self.task_subscriptions:
            for user_id in self.task_subscriptions[task_id]:
                await self.send_personal_message(message, user_id)

    async def broadcast_to_all(self, message: dict):
        """Broadcast a message to all connected users."""
        for user_id, connections in self.active_connections.items():
            for connection in connections:
                try:
                    await connection.send_text(json.dumps(message))
                except Exception as e:
                    logger.error(f"Error broadcasting to user {user_id}: {e}")


# Global connection manager instance
manager = ConnectionManager()


class WebSocketService:
    @staticmethod
    async def authenticate_websocket(websocket: WebSocket, token: str) -> User:
        """Authenticate WebSocket connection using JWT token."""
        try:
            payload = verify_token(token)
            user_id = payload.get("user_id")
            if not user_id:
                raise ValueError("Invalid token payload")
            
            # In a real implementation, you'd fetch the user from the database
            # For now, we'll create a mock user object
            user = User(id=user_id, email=payload.get("sub", ""))
            return user
        except Exception as e:
            logger.error(f"WebSocket authentication failed: {e}")
            await websocket.close(code=1008, reason="Authentication failed")
            raise

    @staticmethod
    async def handle_websocket_connection(websocket: WebSocket, token: str):
        """Handle a new WebSocket connection."""
        try:
            user = await WebSocketService.authenticate_websocket(websocket, token)
            await manager.connect(websocket, user.id)
            
            # Send welcome message
            await manager.send_personal_message({
                "type": "connection_established",
                "message": "Connected to real-time updates",
                "user_id": user.id
            }, user.id)
            
            # Keep connection alive and handle messages
            while True:
                try:
                    data = await websocket.receive_text()
                    message = json.loads(data)
                    await WebSocketService.handle_message(websocket, user.id, message)
                except WebSocketDisconnect:
                    break
                except Exception as e:
                    logger.error(f"Error handling WebSocket message: {e}")
                    await websocket.send_text(json.dumps({
                        "type": "error",
                        "message": "Invalid message format"
                    }))
        
        except Exception as e:
            logger.error(f"WebSocket connection error: {e}")
        finally:
            manager.disconnect(websocket, user.id if 'user' in locals() else None)

    @staticmethod
    async def handle_message(websocket: WebSocket, user_id: int, message: dict):
        """Handle incoming WebSocket messages."""
        message_type = message.get("type")
        
        if message_type == "subscribe_project":
            project_id = message.get("project_id")
            if project_id:
                await manager.subscribe_to_project(user_id, project_id)
                await websocket.send_text(json.dumps({
                    "type": "subscription_confirmed",
                    "project_id": project_id
                }))
        
        elif message_type == "subscribe_task":
            task_id = message.get("task_id")
            if task_id:
                await manager.subscribe_to_task(user_id, task_id)
                await websocket.send_text(json.dumps({
                    "type": "subscription_confirmed",
                    "task_id": task_id
                }))
        
        elif message_type == "ping":
            await websocket.send_text(json.dumps({
                "type": "pong",
                "timestamp": message.get("timestamp")
            }))
        
        else:
            await websocket.send_text(json.dumps({
                "type": "error",
                "message": f"Unknown message type: {message_type}"
            }))

    @staticmethod
    async def notify_project_update(project_id: int, update_type: str, data: dict):
        """Notify all users subscribed to a project about an update."""
        message = {
            "type": "project_update",
            "project_id": project_id,
            "update_type": update_type,
            "data": data,
            "timestamp": data.get("timestamp")
        }
        await manager.broadcast_to_project(message, project_id)

    @staticmethod
    async def notify_task_update(task_id: int, update_type: str, data: dict):
        """Notify all users subscribed to a task about an update."""
        message = {
            "type": "task_update",
            "task_id": task_id,
            "update_type": update_type,
            "data": data,
            "timestamp": data.get("timestamp")
        }
        await manager.broadcast_to_task(message, task_id)

    @staticmethod
    async def notify_user(user_id: int, notification_type: str, data: dict):
        """Send a notification to a specific user."""
        message = {
            "type": "notification",
            "notification_type": notification_type,
            "data": data,
            "timestamp": data.get("timestamp")
        }
        await manager.send_personal_message(message, user_id)
