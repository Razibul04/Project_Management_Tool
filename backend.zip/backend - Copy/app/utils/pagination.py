from typing import List, Dict, Any, Optional
from sqlalchemy.orm import Query
from sqlalchemy import func


class PaginationParams:
    def __init__(self, page: int = 1, per_page: int = 20, max_per_page: int = 100):
        self.page = max(1, page)
        self.per_page = min(max(1, per_page), max_per_page)
        self.offset = (self.page - 1) * self.per_page


def paginate_query(
    query: Query,
    pagination: PaginationParams,
    include_total: bool = True
) -> Dict[str, Any]:
    """
    Paginate a SQLAlchemy query and return paginated results.
    
    Args:
        query: SQLAlchemy query object
        pagination: PaginationParams object
        include_total: Whether to include total count (can be expensive)
    
    Returns:
        Dictionary with paginated results and metadata
    """
    # Get total count if requested
    total = None
    if include_total:
        try:
            total = query.count()
        except Exception:
            # If count fails, we'll skip total
            total = None
    
    # Apply pagination
    paginated_query = query.offset(pagination.offset).limit(pagination.per_page)
    
    # Execute query
    items = paginated_query.all()
    
    # Calculate pagination metadata
    has_prev = pagination.page > 1
    has_next = total is None or (pagination.offset + pagination.per_page) < total
    
    prev_page = pagination.page - 1 if has_prev else None
    next_page = pagination.page + 1 if has_next else None
    
    total_pages = None
    if total is not None:
        total_pages = (total + pagination.per_page - 1) // pagination.per_page
    
    return {
        "items": items,
        "pagination": {
            "page": pagination.page,
            "per_page": pagination.per_page,
            "total": total,
            "total_pages": total_pages,
            "has_prev": has_prev,
            "has_next": has_next,
            "prev_page": prev_page,
            "next_page": next_page
        }
    }


def create_pagination_links(
    base_url: str,
    page: int,
    per_page: int,
    total_pages: Optional[int],
    has_prev: bool,
    has_next: bool
) -> Dict[str, Optional[str]]:
    """
    Create pagination links for API responses.
    
    Args:
        base_url: Base URL for the API endpoint
        page: Current page number
        per_page: Items per page
        total_pages: Total number of pages
        has_prev: Whether previous page exists
        has_next: Whether next page exists
    
    Returns:
        Dictionary with pagination links
    """
    links = {
        "first": f"{base_url}?page=1&per_page={per_page}",
        "last": None,
        "prev": None,
        "next": None
    }
    
    if total_pages:
        links["last"] = f"{base_url}?page={total_pages}&per_page={per_page}"
    
    if has_prev:
        links["prev"] = f"{base_url}?page={page - 1}&per_page={per_page}"
    
    if has_next:
        links["next"] = f"{base_url}?page={page + 1}&per_page={per_page}"
    
    return links


def validate_pagination_params(
    page: Optional[int] = None,
    per_page: Optional[int] = None,
    max_per_page: int = 100
) -> PaginationParams:
    """
    Validate and create pagination parameters.
    
    Args:
        page: Page number (1-based)
        per_page: Items per page
        max_per_page: Maximum allowed items per page
    
    Returns:
        Validated PaginationParams object
    """
    # Default values
    page = page or 1
    per_page = per_page or 20
    
    # Validate page
    if page < 1:
        page = 1
    
    # Validate per_page
    if per_page < 1:
        per_page = 20
    elif per_page > max_per_page:
        per_page = max_per_page
    
    return PaginationParams(page=page, per_page=per_page, max_per_page=max_per_page)
