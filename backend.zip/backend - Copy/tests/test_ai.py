import pytest
from unittest.mock import patch, MagicMock
from fastapi.testclient import TestClient


@patch('app.services.ai_service.groq.Groq')
def test_generate_user_stories_success(mock_groq, client, pm_auth_headers):
    """Test successful user story generation."""
    # Mock the AI response
    mock_response = MagicMock()
    mock_response.choices = [MagicMock()]
    mock_response.choices[0].message.content = """
    As a user, I want to create an account, so that I can access the application.
    As a user, I want to login to my account, so that I can manage my projects.
    As a project manager, I want to create projects, so that I can organize work.
    As a developer, I want to view assigned tasks, so that I can complete my work.
    As a user, I want to track project progress, so that I can monitor completion.
    """
    
    mock_groq.return_value.chat.completions.create.return_value = mock_response
    
    response = client.post("/api/ai/generate-user-stories", json={
        "project_description": "A project management tool",
        "num_stories": 5
    }, headers=pm_auth_headers)
    
    assert response.status_code == 200
    data = response.json()
    assert "stories" in data
    assert len(data["stories"]) > 0
    assert all(story.startswith("As a") for story in data["stories"])


def test_generate_user_stories_unauthorized(client, auth_headers):
    """Test user story generation without proper permissions."""
    response = client.post("/api/ai/generate-user-stories", json={
        "project_description": "A project management tool",
        "num_stories": 5
    }, headers=auth_headers)
    
    assert response.status_code == 403
    assert "Only project managers and admins" in response.json()["detail"]


@patch('app.services.ai_service.groq.Groq')
def test_generate_tasks_from_stories_success(mock_groq, client, pm_auth_headers):
    """Test successful task generation from user stories."""
    # Mock the AI response
    mock_response = MagicMock()
    mock_response.choices = [MagicMock()]
    mock_response.choices[0].message.content = """
    Task: Create user registration form | Priority: high | Estimated Hours: 8
    Task: Implement login functionality | Priority: high | Estimated Hours: 6
    Task: Design project creation interface | Priority: medium | Estimated Hours: 12
    Task: Build task assignment system | Priority: medium | Estimated Hours: 10
    Task: Create progress tracking dashboard | Priority: low | Estimated Hours: 16
    """
    
    mock_groq.return_value.chat.completions.create.return_value = mock_response
    
    response = client.post("/api/ai/generate-tasks", json={
        "user_stories": [
            "As a user, I want to create an account, so that I can access the application.",
            "As a project manager, I want to create projects, so that I can organize work."
        ]
    }, headers=pm_auth_headers)
    
    assert response.status_code == 200
    data = response.json()
    assert "tasks" in data
    assert len(data["tasks"]) > 0
    assert all("title" in task for task in data["tasks"])
    assert all("priority" in task for task in data["tasks"])


def test_generate_tasks_unauthorized(client, auth_headers):
    """Test task generation without proper permissions."""
    response = client.post("/api/ai/generate-tasks", json={
        "user_stories": [
            "As a user, I want to create an account, so that I can access the application."
        ]
    }, headers=auth_headers)
    
    assert response.status_code == 403
    assert "Only project managers and admins" in response.json()["detail"]


@patch('app.services.ai_service.groq.Groq')
def test_ai_service_error_handling(mock_groq, client, pm_auth_headers):
    """Test AI service error handling."""
    # Mock an exception
    mock_groq.return_value.chat.completions.create.side_effect = Exception("API Error")
    
    response = client.post("/api/ai/generate-user-stories", json={
        "project_description": "A project management tool",
        "num_stories": 5
    }, headers=pm_auth_headers)
    
    assert response.status_code == 500
    assert "Failed to generate user stories" in response.json()["detail"]
