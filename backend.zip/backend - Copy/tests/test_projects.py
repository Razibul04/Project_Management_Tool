import pytest
from fastapi.testclient import TestClient
from app.models.project import Project, ProjectStatus


def test_create_project(client, pm_auth_headers):
    """Test creating a new project."""
    response = client.post("/api/projects/", json={
        "title": "Test Project",
        "description": "A test project",
        "status": "planning",
        "deadline": "2024-12-31T23:59:59"
    }, headers=pm_auth_headers)
    
    assert response.status_code == 200
    data = response.json()
    assert data["title"] == "Test Project"
    assert data["description"] == "A test project"
    assert data["status"] == "planning"
    assert "id" in data


def test_create_project_unauthorized(client, auth_headers):
    """Test creating project without proper permissions."""
    response = client.post("/api/projects/", json={
        "title": "Test Project",
        "description": "A test project",
        "status": "planning"
    }, headers=auth_headers)
    
    assert response.status_code == 403


def test_get_projects(client, pm_auth_headers):
    """Test getting projects list."""
    # First create a project
    client.post("/api/projects/", json={
        "title": "Test Project",
        "description": "A test project",
        "status": "planning"
    }, headers=pm_auth_headers)
    
    response = client.get("/api/projects/", headers=pm_auth_headers)
    
    assert response.status_code == 200
    data = response.json()
    assert len(data) == 1
    assert data[0]["title"] == "Test Project"


def test_get_project_by_id(client, pm_auth_headers):
    """Test getting a specific project."""
    # Create a project
    create_response = client.post("/api/projects/", json={
        "title": "Test Project",
        "description": "A test project",
        "status": "planning"
    }, headers=pm_auth_headers)
    
    project_id = create_response.json()["id"]
    
    response = client.get(f"/api/projects/{project_id}", headers=pm_auth_headers)
    
    assert response.status_code == 200
    data = response.json()
    assert data["title"] == "Test Project"
    assert data["id"] == project_id


def test_update_project(client, pm_auth_headers):
    """Test updating a project."""
    # Create a project
    create_response = client.post("/api/projects/", json={
        "title": "Test Project",
        "description": "A test project",
        "status": "planning"
    }, headers=pm_auth_headers)
    
    project_id = create_response.json()["id"]
    
    # Update the project
    response = client.put(f"/api/projects/{project_id}", json={
        "title": "Updated Project",
        "status": "in_progress"
    }, headers=pm_auth_headers)
    
    assert response.status_code == 200
    data = response.json()
    assert data["title"] == "Updated Project"
    assert data["status"] == "in_progress"


def test_delete_project(client, pm_auth_headers):
    """Test deleting a project."""
    # Create a project
    create_response = client.post("/api/projects/", json={
        "title": "Test Project",
        "description": "A test project",
        "status": "planning"
    }, headers=pm_auth_headers)
    
    project_id = create_response.json()["id"]
    
    # Delete the project
    response = client.delete(f"/api/projects/{project_id}", headers=pm_auth_headers)
    
    assert response.status_code == 200
    assert "deleted successfully" in response.json()["message"]
    
    # Verify project is deleted
    get_response = client.get(f"/api/projects/{project_id}", headers=pm_auth_headers)
    assert get_response.status_code == 404


def test_add_project_member(client, pm_auth_headers, test_user):
    """Test adding a member to a project."""
    # Create a project
    create_response = client.post("/api/projects/", json={
        "title": "Test Project",
        "description": "A test project",
        "status": "planning"
    }, headers=pm_auth_headers)
    
    project_id = create_response.json()["id"]
    
    # Add a member
    response = client.post(f"/api/projects/{project_id}/members", json={
        "user_id": test_user.id,
        "role": "member"
    }, headers=pm_auth_headers)
    
    assert response.status_code == 200
    data = response.json()
    assert data["user_id"] == test_user.id
    assert data["role"] == "member"


def test_get_project_members(client, pm_auth_headers, test_user):
    """Test getting project members."""
    # Create a project
    create_response = client.post("/api/projects/", json={
        "title": "Test Project",
        "description": "A test project",
        "status": "planning"
    }, headers=pm_auth_headers)
    
    project_id = create_response.json()["id"]
    
    # Add a member
    client.post(f"/api/projects/{project_id}/members", json={
        "user_id": test_user.id,
        "role": "member"
    }, headers=pm_auth_headers)
    
    # Get members
    response = client.get(f"/api/projects/{project_id}/members", headers=pm_auth_headers)
    
    assert response.status_code == 200
    data = response.json()
    assert len(data) >= 1  # At least the owner
