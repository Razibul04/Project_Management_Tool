import pytest
from fastapi.testclient import TestClient
from app.models.task import TaskStatus, TaskPriority


def test_create_task(client, pm_auth_headers, test_user):
    """Test creating a new task."""
    # First create a project
    project_response = client.post("/api/projects/", json={
        "title": "Test Project",
        "description": "A test project",
        "status": "planning"
    }, headers=pm_auth_headers)
    
    project_id = project_response.json()["id"]
    
    # Create a task
    response = client.post("/api/tasks/", json={
        "title": "Test Task",
        "description": "A test task",
        "status": "todo",
        "priority": "medium",
        "project_id": project_id,
        "assigned_user_id": test_user.id
    }, headers=pm_auth_headers)
    
    assert response.status_code == 200
    data = response.json()
    assert data["title"] == "Test Task"
    assert data["description"] == "A test task"
    assert data["status"] == "todo"
    assert data["priority"] == "medium"
    assert data["project_id"] == project_id
    assert data["assigned_user_id"] == test_user.id


def test_get_tasks(client, pm_auth_headers, test_user):
    """Test getting tasks list."""
    # Create a project and task
    project_response = client.post("/api/projects/", json={
        "title": "Test Project",
        "description": "A test project",
        "status": "planning"
    }, headers=pm_auth_headers)
    
    project_id = project_response.json()["id"]
    
    client.post("/api/tasks/", json={
        "title": "Test Task",
        "description": "A test task",
        "status": "todo",
        "priority": "medium",
        "project_id": project_id,
        "assigned_user_id": test_user.id
    }, headers=pm_auth_headers)
    
    response = client.get("/api/tasks/", headers=pm_auth_headers)
    
    assert response.status_code == 200
    data = response.json()
    assert len(data) == 1
    assert data[0]["title"] == "Test Task"


def test_get_task_by_id(client, pm_auth_headers, test_user):
    """Test getting a specific task."""
    # Create a project and task
    project_response = client.post("/api/projects/", json={
        "title": "Test Project",
        "description": "A test project",
        "status": "planning"
    }, headers=pm_auth_headers)
    
    project_id = project_response.json()["id"]
    
    task_response = client.post("/api/tasks/", json={
        "title": "Test Task",
        "description": "A test task",
        "status": "todo",
        "priority": "medium",
        "project_id": project_id,
        "assigned_user_id": test_user.id
    }, headers=pm_auth_headers)
    
    task_id = task_response.json()["id"]
    
    response = client.get(f"/api/tasks/{task_id}", headers=pm_auth_headers)
    
    assert response.status_code == 200
    data = response.json()
    assert data["title"] == "Test Task"
    assert data["id"] == task_id


def test_update_task(client, pm_auth_headers, test_user):
    """Test updating a task."""
    # Create a project and task
    project_response = client.post("/api/projects/", json={
        "title": "Test Project",
        "description": "A test project",
        "status": "planning"
    }, headers=pm_auth_headers)
    
    project_id = project_response.json()["id"]
    
    task_response = client.post("/api/tasks/", json={
        "title": "Test Task",
        "description": "A test task",
        "status": "todo",
        "priority": "medium",
        "project_id": project_id,
        "assigned_user_id": test_user.id
    }, headers=pm_auth_headers)
    
    task_id = task_response.json()["id"]
    
    # Update the task
    response = client.put(f"/api/tasks/{task_id}", json={
        "title": "Updated Task",
        "status": "in_progress"
    }, headers=pm_auth_headers)
    
    assert response.status_code == 200
    data = response.json()
    assert data["title"] == "Updated Task"
    assert data["status"] == "in_progress"


def test_delete_task(client, pm_auth_headers, test_user):
    """Test deleting a task."""
    # Create a project and task
    project_response = client.post("/api/projects/", json={
        "title": "Test Project",
        "description": "A test project",
        "status": "planning"
    }, headers=pm_auth_headers)
    
    project_id = project_response.json()["id"]
    
    task_response = client.post("/api/tasks/", json={
        "title": "Test Task",
        "description": "A test task",
        "status": "todo",
        "priority": "medium",
        "project_id": project_id,
        "assigned_user_id": test_user.id
    }, headers=pm_auth_headers)
    
    task_id = task_response.json()["id"]
    
    # Delete the task
    response = client.delete(f"/api/tasks/{task_id}", headers=pm_auth_headers)
    
    assert response.status_code == 200
    assert "deleted successfully" in response.json()["message"]
    
    # Verify task is deleted
    get_response = client.get(f"/api/tasks/{task_id}", headers=pm_auth_headers)
    assert get_response.status_code == 404


def test_add_task_comment(client, pm_auth_headers, test_user):
    """Test adding a comment to a task."""
    # Create a project and task
    project_response = client.post("/api/projects/", json={
        "title": "Test Project",
        "description": "A test project",
        "status": "planning"
    }, headers=pm_auth_headers)
    
    project_id = project_response.json()["id"]
    
    task_response = client.post("/api/tasks/", json={
        "title": "Test Task",
        "description": "A test task",
        "status": "todo",
        "priority": "medium",
        "project_id": project_id,
        "assigned_user_id": test_user.id
    }, headers=pm_auth_headers)
    
    task_id = task_response.json()["id"]
    
    # Add a comment
    response = client.post(f"/api/tasks/{task_id}/comments", json={
        "content": "This is a test comment",
        "task_id": task_id
    }, headers=pm_auth_headers)
    
    assert response.status_code == 200
    data = response.json()
    assert data["content"] == "This is a test comment"
    assert data["task_id"] == task_id


def test_get_task_comments(client, pm_auth_headers, test_user):
    """Test getting task comments."""
    # Create a project and task
    project_response = client.post("/api/projects/", json={
        "title": "Test Project",
        "description": "A test project",
        "status": "planning"
    }, headers=pm_auth_headers)
    
    project_id = project_response.json()["id"]
    
    task_response = client.post("/api/tasks/", json={
        "title": "Test Task",
        "description": "A test task",
        "status": "todo",
        "priority": "medium",
        "project_id": project_id,
        "assigned_user_id": test_user.id
    }, headers=pm_auth_headers)
    
    task_id = task_response.json()["id"]
    
    # Add a comment
    client.post(f"/api/tasks/{task_id}/comments", json={
        "content": "This is a test comment",
        "task_id": task_id
    }, headers=pm_auth_headers)
    
    # Get comments
    response = client.get(f"/api/tasks/{task_id}/comments", headers=pm_auth_headers)
    
    assert response.status_code == 200
    data = response.json()
    assert len(data) == 1
    assert data[0]["content"] == "This is a test comment"


def test_get_dashboard_stats(client, pm_auth_headers, test_user):
    """Test getting dashboard statistics."""
    # Create a project and task
    project_response = client.post("/api/projects/", json={
        "title": "Test Project",
        "description": "A test project",
        "status": "planning"
    }, headers=pm_auth_headers)
    
    project_id = project_response.json()["id"]
    
    client.post("/api/tasks/", json={
        "title": "Test Task",
        "description": "A test task",
        "status": "todo",
        "priority": "medium",
        "project_id": project_id,
        "assigned_user_id": test_user.id
    }, headers=pm_auth_headers)
    
    response = client.get("/api/tasks/dashboard/stats", headers=pm_auth_headers)
    
    assert response.status_code == 200
    data = response.json()
    assert "total_tasks" in data
    assert "todo_tasks" in data
    assert "in_progress_tasks" in data
    assert "done_tasks" in data
    assert "overdue_tasks" in data
    assert "total_projects" in data
    assert "active_projects" in data
    assert data["total_tasks"] == 1
    assert data["todo_tasks"] == 1
