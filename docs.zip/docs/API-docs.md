# API Documentation

## Base URL
```
http://localhost:8000/api
```

## Authentication

All protected endpoints require a JWT token in the Authorization header:
```
Authorization: Bearer <your-jwt-token>
```

## Endpoints

### Authentication

#### POST /auth/register
Register a new user.

**Request Body:**
```json
{
  "name": "John Doe",
  "email": "john@example.com",
  "password": "password123",
  "role": "developer"
}
```

**Response:**
```json
{
  "id": 1,
  "name": "John Doe",
  "email": "john@example.com",
  "role": "developer",
  "created_at": "2024-01-01T00:00:00Z"
}
```

#### POST /auth/login
Login and get access token.

**Request Body:**
```json
{
  "email": "john@example.com",
  "password": "password123"
}
```

**Response:**
```json
{
  "access_token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
  "token_type": "bearer"
}
```

#### GET /auth/me
Get current user information.

**Response:**
```json
{
  "id": 1,
  "name": "John Doe",
  "email": "john@example.com",
  "role": "developer",
  "created_at": "2024-01-01T00:00:00Z"
}
```

### Users

#### GET /users/
Get all users (Admin only).

**Query Parameters:**
- `skip`: Number of records to skip (default: 0)
- `limit`: Maximum number of records to return (default: 100)

#### GET /users/{user_id}
Get user by ID.

#### PUT /users/{user_id}
Update user information.

#### DELETE /users/{user_id}
Delete user (Admin only).

### Projects

#### POST /projects/
Create a new project.

**Request Body:**
```json
{
  "title": "My Project",
  "description": "Project description",
  "status": "planning",
  "deadline": "2024-12-31T23:59:59Z"
}
```

#### GET /projects/
Get all accessible projects.

#### GET /projects/{project_id}
Get project by ID.

#### PUT /projects/{project_id}
Update project.

#### DELETE /projects/{project_id}
Delete project.

#### POST /projects/{project_id}/members
Add member to project.

**Request Body:**
```json
{
  "user_id": 1,
  "role": "member"
}
```

#### GET /projects/{project_id}/members
Get project members.

### Tasks

#### POST /tasks/
Create a new task.

**Request Body:**
```json
{
  "title": "My Task",
  "description": "Task description",
  "status": "todo",
  "priority": "medium",
  "deadline": "2024-12-31T23:59:59Z",
  "project_id": 1,
  "assigned_user_id": 1
}
```

#### GET /tasks/
Get tasks with optional filters.

**Query Parameters:**
- `project_id`: Filter by project
- `assigned_to`: Filter by assigned user
- `status`: Filter by status
- `skip`: Number of records to skip
- `limit`: Maximum number of records to return

#### GET /tasks/{task_id}
Get task by ID with details.

#### PUT /tasks/{task_id}
Update task.

#### DELETE /tasks/{task_id}
Delete task.

#### POST /tasks/{task_id}/comments
Add comment to task.

**Request Body:**
```json
{
  "content": "This is a comment",
  "task_id": 1
}
```

#### GET /tasks/{task_id}/comments
Get task comments.

#### GET /tasks/dashboard/stats
Get dashboard statistics.

**Response:**
```json
{
  "total_tasks": 10,
  "todo_tasks": 3,
  "in_progress_tasks": 4,
  "done_tasks": 3,
  "overdue_tasks": 1,
  "total_projects": 5,
  "active_projects": 3
}
```

### AI Features

#### POST /ai/generate-user-stories
Generate user stories for a project (Project Manager/Admin only).

**Request Body:**
```json
{
  "project_description": "A project management tool",
  "num_stories": 5
}
```

**Response:**
```json
{
  "stories": [
    "As a user, I want to create an account, so that I can access the application.",
    "As a project manager, I want to create projects, so that I can organize work."
  ]
}
```

#### POST /ai/generate-tasks
Generate tasks from user stories (Project Manager/Admin only).

**Request Body:**
```json
{
  "user_stories": [
    "As a user, I want to create an account, so that I can access the application."
  ]
}
```

**Response:**
```json
{
  "tasks": [
    {
      "title": "Create user registration form",
      "priority": "high",
      "estimated_hours": 8
    }
  ]
}
```

## Error Responses

All endpoints return appropriate HTTP status codes and error messages:

```json
{
  "detail": "Error message"
}
```

Common status codes:
- `200`: Success
- `201`: Created
- `400`: Bad Request
- `401`: Unauthorized
- `403`: Forbidden
- `404`: Not Found
- `422`: Validation Error
- `500`: Internal Server Error
