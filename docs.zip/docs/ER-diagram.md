# Entity Relationship Diagram

## Database Schema

```
┌─────────────────┐
│      Users      │
├─────────────────┤
│ id (PK)         │
│ name            │
│ email (UNIQUE)  │
│ hashed_password │
│ role            │
│ created_at      │
│ updated_at      │
└─────────────────┘
         │
         │ 1:N
         ▼
┌─────────────────┐
│    Projects     │
├─────────────────┤
│ id (PK)         │
│ title           │
│ description     │
│ status          │
│ deadline        │
│ owner_id (FK)   │
│ created_at      │
│ updated_at      │
└─────────────────┘
         │
         │ 1:N
         ▼
┌─────────────────┐
│      Tasks      │
├─────────────────┤
│ id (PK)         │
│ title           │
│ description     │
│ status          │
│ priority        │
│ deadline        │
│ project_id (FK) │
│ assigned_user_id│
│ created_at      │
│ updated_at      │
└─────────────────┘
         │
         │ 1:N
         ▼
┌─────────────────┐
│    Comments     │
├─────────────────┤
│ id (PK)         │
│ content         │
│ task_id (FK)    │
│ user_id (FK)    │
│ created_at      │
│ updated_at      │
└─────────────────┘

┌─────────────────┐
│ Project Members │
├─────────────────┤
│ id (PK)         │
│ project_id (FK) │
│ user_id (FK)    │
│ role            │
│ joined_at       │
└─────────────────┘
```

## Relationships

1. **Users → Projects**: One-to-Many
   - A user can own multiple projects
   - Each project has one owner

2. **Projects → Tasks**: One-to-Many
   - A project can have multiple tasks
   - Each task belongs to one project

3. **Users → Tasks**: One-to-Many (Assignment)
   - A user can be assigned to multiple tasks
   - Each task can be assigned to one user (optional)

4. **Tasks → Comments**: One-to-Many
   - A task can have multiple comments
   - Each comment belongs to one task

5. **Users → Comments**: One-to-Many
   - A user can write multiple comments
   - Each comment is written by one user

6. **Projects ↔ Users**: Many-to-Many (Project Members)
   - A project can have multiple members
   - A user can be a member of multiple projects

## User Roles

- **Admin**: Full system access
- **Project Manager**: Can manage projects and tasks
- **Developer**: Can update assigned tasks and add comments

## Status Enums

### Project Status
- `planning`: Project is in planning phase
- `in_progress`: Project is actively being worked on
- `completed`: Project is finished
- `on_hold`: Project is temporarily paused

### Task Status
- `todo`: Task is not started
- `in_progress`: Task is being worked on
- `done`: Task is completed

### Task Priority
- `low`: Low priority task
- `medium`: Medium priority task
- `high`: High priority task
- `urgent`: Urgent task requiring immediate attention
