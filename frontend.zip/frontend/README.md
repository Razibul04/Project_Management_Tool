# Frontend - Project Management Tool

React-based frontend for the Project Management Tool with Material-UI, authentication, and real-time dashboard.

## 🚀 Quick Start

### Prerequisites
- Node.js 18+
- npm or yarn

### Installation

1. **Navigate to frontend directory**
   ```bash
   cd frontend
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Start development server**
   ```bash
   npm start
   ```

The application will be available at http://localhost:3000

## 🏗️ Project Structure

```
frontend/
├── public/
│   ├── index.html
│   └── manifest.json
├── src/
│   ├── api/                 # API client functions
│   │   ├── auth.js
│   │   ├── projects.js
│   │   ├── tasks.js
│   │   └── ai.js
│   ├── components/          # Reusable components
│   │   ├── Navbar.jsx
│   │   ├── ProtectedRoute.jsx
│   │   └── Dashboard.jsx
│   ├── pages/              # Page components
│   │   ├── Login.jsx
│   │   ├── Register.jsx
│   │   ├── Dashboard.jsx
│   │   ├── Projects.jsx
│   │   └── Tasks.jsx
│   ├── utils/              # Utility functions
│   │   └── auth.js
│   ├── App.jsx             # Main app component
│   └── index.js            # Entry point
├── package.json
└── README.md
```

## 🎨 UI Components

### Material-UI Components Used
- **AppBar**: Navigation bar
- **Card**: Project and task cards
- **Dialog**: Modal forms
- **TextField**: Form inputs
- **Button**: Action buttons
- **Chip**: Status indicators
- **Tabs**: Task status tabs
- **Grid**: Layout system
- **Typography**: Text styling

### Charts and Visualization
- **Recharts**: Dashboard charts
- **PieChart**: Task status distribution
- **BarChart**: Project statistics

## 🔐 Authentication

### Authentication Flow
1. User registers/logs in
2. JWT token stored in localStorage
3. Token included in API requests
4. Protected routes check authentication
5. Automatic logout on token expiration

### Protected Routes
- Dashboard
- Projects
- Tasks
- User management (Admin only)

## 📱 Pages

### Login/Register
- Form validation
- Error handling
- Role selection
- Password confirmation

### Dashboard
- Statistics cards
- Task status pie chart
- Project status bar chart
- Recent projects overview

### Projects
- Project grid view
- Create/edit project dialog
- Status management
- Member management
- Project filtering

### Tasks
- Kanban-style board
- Task status tabs (To Do, In Progress, Done)
- Task details panel
- Comment system
- Priority indicators

## 🎯 Features

### Core Features
- **Responsive Design**: Mobile-friendly interface
- **Real-time Updates**: Live data from API
- **Role-based UI**: Different views for different roles
- **Form Validation**: Client-side validation
- **Error Handling**: User-friendly error messages
- **Loading States**: Loading indicators

### Advanced Features
- **Drag & Drop**: Task status updates (future)
- **Search & Filter**: Task and project filtering
- **Export**: Data export functionality (future)
- **Notifications**: Real-time notifications (future)

## 🔧 Configuration

### Environment Variables

Create a `.env` file in the frontend directory:

```env
REACT_APP_API_URL=http://localhost:8000
```

### API Configuration

The frontend uses axios for API calls with automatic token handling:

```javascript
// Automatic token inclusion
axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
```

## 🎨 Styling

### Material-UI Theme
- Custom color palette
- Consistent typography
- Responsive breakpoints
- Dark mode support (future)

### Component Styling
- Inline styles with `sx` prop
- Theme-based colors
- Responsive design
- Accessibility features

## 📊 State Management

### Context API
- **AuthContext**: User authentication state
- **ThemeContext**: UI theme state (future)

### Local State
- Component-level state with hooks
- Form state management
- Loading and error states

## 🧪 Testing

### Available Scripts
```bash
npm start          # Start development server
npm test           # Run tests
npm run build      # Build for production
npm run eject      # Eject from Create React App
```

### Testing Strategy
- Unit tests for components
- Integration tests for API calls
- E2E tests for user flows (future)

## 🚀 Deployment

### Production Build
```bash
npm run build
```

### Docker Deployment
```bash
docker build -t project-management-frontend .
docker run -p 80:80 project-management-frontend
```

### Environment Configuration
- Production API URL
- Analytics tracking
- Error reporting
- Performance monitoring

## 📱 Responsive Design

### Breakpoints
- **xs**: 0px and up
- **sm**: 600px and up
- **md**: 960px and up
- **lg**: 1280px and up
- **xl**: 1920px and up

### Mobile Features
- Touch-friendly interface
- Swipe gestures (future)
- Mobile navigation
- Optimized forms

## 🔍 Performance

### Optimization Techniques
- Code splitting
- Lazy loading
- Image optimization
- Bundle analysis
- Caching strategies

### Monitoring
- Performance metrics
- Error tracking
- User analytics
- API response times

## 🛡️ Security

### Client-side Security
- Input sanitization
- XSS prevention
- CSRF protection
- Secure token storage
- HTTPS enforcement

### Best Practices
- No sensitive data in client
- Secure API communication
- Regular dependency updates
- Security headers

## 🔧 Development

### Code Style
- ESLint configuration
- Prettier formatting
- Component naming conventions
- File organization

### Adding New Features
1. Create component in appropriate directory
2. Add routing if needed
3. Implement API integration
4. Add tests
5. Update documentation

### Component Guidelines
- Use functional components with hooks
- Implement proper prop types
- Add error boundaries
- Follow accessibility guidelines

## 📚 Dependencies

### Core Dependencies
- **React**: UI framework
- **Material-UI**: Component library
- **React Router**: Navigation
- **Axios**: HTTP client
- **Recharts**: Data visualization

### Development Dependencies
- **React Scripts**: Build tools
- **ESLint**: Code linting
- **Jest**: Testing framework
- **Testing Library**: Component testing

## 🎯 Future Enhancements

### Planned Features
- Real-time notifications
- File uploads
- Advanced filtering
- Export functionality
- Dark mode
- Mobile app
- Offline support

### Performance Improvements
- Virtual scrolling
- Image lazy loading
- Service worker
- Progressive Web App features

## 📝 License

MIT License - see main README for details.

## 🆘 Troubleshooting

### Common Issues

1. **API Connection Issues**
   - Check API URL configuration
   - Verify backend is running
   - Check CORS settings

2. **Authentication Problems**
   - Clear localStorage
   - Check token expiration
   - Verify user permissions

3. **Build Issues**
   - Clear node_modules
   - Update dependencies
   - Check Node.js version

### Getting Help
- Check browser console for errors
- Review API documentation
- Check network tab for failed requests
- Verify environment configuration
