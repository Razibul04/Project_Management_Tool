import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000';

const projectsAPI = {
  getProjects: async () => {
    const response = await axios.get(`${API_BASE_URL}/api/projects/`);
    return response.data;
  },

  getProject: async (projectId) => {
    const response = await axios.get(`${API_BASE_URL}/api/projects/${projectId}`);
    return response.data;
  },

  createProject: async (projectData) => {
    const response = await axios.post(`${API_BASE_URL}/api/projects/`, projectData);
    return response.data;
  },

  updateProject: async (projectId, projectData) => {
    const response = await axios.put(`${API_BASE_URL}/api/projects/${projectId}`, projectData);
    return response.data;
  },

  deleteProject: async (projectId) => {
    const response = await axios.delete(`${API_BASE_URL}/api/projects/${projectId}`);
    return response.data;
  },

  getProjectMembers: async (projectId) => {
    const response = await axios.get(`${API_BASE_URL}/api/projects/${projectId}/members`);
    return response.data;
  },

  addProjectMember: async (projectId, memberData) => {
    const response = await axios.post(`${API_BASE_URL}/api/projects/${projectId}/members`, memberData);
    return response.data;
  },
};

export default projectsAPI;
