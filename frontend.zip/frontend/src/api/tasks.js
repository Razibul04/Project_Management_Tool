import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000';

const tasksAPI = {
  getTasks: async (params = {}) => {
    const response = await axios.get(`${API_BASE_URL}/api/tasks/`, { params });
    return response.data;
  },

  getTask: async (taskId) => {
    const response = await axios.get(`${API_BASE_URL}/api/tasks/${taskId}`);
    return response.data;
  },

  createTask: async (taskData) => {
    const response = await axios.post(`${API_BASE_URL}/api/tasks/`, taskData);
    return response.data;
  },

  updateTask: async (taskId, taskData) => {
    const response = await axios.put(`${API_BASE_URL}/api/tasks/${taskId}`, taskData);
    return response.data;
  },

  deleteTask: async (taskId) => {
    const response = await axios.delete(`${API_BASE_URL}/api/tasks/${taskId}`);
    return response.data;
  },

  getTaskComments: async (taskId) => {
    const response = await axios.get(`${API_BASE_URL}/api/tasks/${taskId}/comments`);
    return response.data;
  },

  addTaskComment: async (taskId, commentData) => {
    const response = await axios.post(`${API_BASE_URL}/api/tasks/${taskId}/comments`, commentData);
    return response.data;
  },

  getDashboardStats: async () => {
    const response = await axios.get(`${API_BASE_URL}/api/tasks/dashboard/stats`);
    return response.data;
  },
};

export default tasksAPI;
