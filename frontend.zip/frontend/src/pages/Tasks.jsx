import React, { useState, useEffect } from 'react';
import {
  Container,
  Typography,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Grid,
  Card,
  CardContent,
  CardActions,
  Chip,
  Box,
  Alert,
  CircularProgress,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Tabs,
  Tab,
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
  IconButton,
  Divider,
} from '@mui/material';
import {
  Add,
  Edit,
  Delete,
  Comment,
  Person,
  Schedule,
} from '@mui/icons-material';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import tasksAPI from '../api/tasks';
import projectsAPI from '../api/projects';

const Tasks = () => {
  const [tasks, setTasks] = useState([]);
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [openDialog, setOpenDialog] = useState(false);
  const [editingTask, setEditingTask] = useState(null);
  const [selectedTab, setSelectedTab] = useState(0);
  const [selectedTask, setSelectedTask] = useState(null);
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState('');
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    status: 'todo',
    priority: 'medium',
    deadline: null,
    project_id: '',
    assigned_user_id: '',
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [tasksResponse, projectsResponse] = await Promise.all([
        tasksAPI.getTasks(),
        projectsAPI.getProjects(),
      ]);
      
      setTasks(tasksResponse);
      setProjects(projectsResponse);
    } catch (err) {
      setError('Failed to load data');
      console.error('Data fetch error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleOpenDialog = (task = null) => {
    if (task) {
      setEditingTask(task);
      setFormData({
        title: task.title,
        description: task.description || '',
        status: task.status,
        priority: task.priority,
        deadline: task.deadline ? new Date(task.deadline) : null,
        project_id: task.project_id,
        assigned_user_id: task.assigned_user_id || '',
      });
    } else {
      setEditingTask(null);
      setFormData({
        title: '',
        description: '',
        status: 'todo',
        priority: 'medium',
        deadline: null,
        project_id: '',
        assigned_user_id: '',
      });
    }
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
    setEditingTask(null);
    setFormData({
      title: '',
      description: '',
      status: 'todo',
      priority: 'medium',
      deadline: null,
      project_id: '',
      assigned_user_id: '',
    });
  };

  const handleSubmit = async () => {
    try {
      const taskData = {
        ...formData,
        deadline: formData.deadline?.toISOString(),
        assigned_user_id: formData.assigned_user_id || null,
      };

      if (editingTask) {
        await tasksAPI.updateTask(editingTask.id, taskData);
      } else {
        await tasksAPI.createTask(taskData);
      }

      await fetchData();
      handleCloseDialog();
    } catch (err) {
      setError('Failed to save task');
      console.error('Save task error:', err);
    }
  };

  const handleDelete = async (taskId) => {
    if (window.confirm('Are you sure you want to delete this task?')) {
      try {
        await tasksAPI.deleteTask(taskId);
        await fetchData();
      } catch (err) {
        setError('Failed to delete task');
        console.error('Delete task error:', err);
      }
    }
  };

  const handleTaskClick = async (task) => {
    setSelectedTask(task);
    try {
      const commentsResponse = await tasksAPI.getTaskComments(task.id);
      setComments(commentsResponse);
    } catch (err) {
      console.error('Failed to load comments:', err);
    }
  };

  const handleAddComment = async () => {
    if (!newComment.trim() || !selectedTask) return;

    try {
      await tasksAPI.addTaskComment(selectedTask.id, {
        content: newComment,
        task_id: selectedTask.id,
      });
      setNewComment('');
      // Refresh comments
      const commentsResponse = await tasksAPI.getTaskComments(selectedTask.id);
      setComments(commentsResponse);
    } catch (err) {
      setError('Failed to add comment');
      console.error('Add comment error:', err);
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'todo':
        return 'default';
      case 'in_progress':
        return 'primary';
      case 'done':
        return 'success';
      default:
        return 'default';
    }
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'low':
        return 'success';
      case 'medium':
        return 'warning';
      case 'high':
        return 'error';
      case 'urgent':
        return 'error';
      default:
        return 'default';
    }
  };

  const filteredTasks = tasks.filter(task => {
    switch (selectedTab) {
      case 0:
        return task.status === 'todo';
      case 1:
        return task.status === 'in_progress';
      case 2:
        return task.status === 'done';
      default:
        return true;
    }
  });

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="50vh">
        <CircularProgress />
      </Box>
    );
  }

  return (
    <LocalizationProvider dateAdapter={AdapterDateFns}>
      <Container maxWidth="lg">
        <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
          <Typography variant="h4">Tasks</Typography>
          <Button
            variant="contained"
            startIcon={<Add />}
            onClick={() => handleOpenDialog()}
          >
            New Task
          </Button>
        </Box>

        {error && (
          <Alert severity="error" sx={{ mb: 2 }}>
            {error}
          </Alert>
        )}

        <Grid container spacing={3}>
          <Grid item xs={12} md={8}>
            <Card>
              <Tabs
                value={selectedTab}
                onChange={(e, newValue) => setSelectedTab(newValue)}
                aria-label="task status tabs"
              >
                <Tab label={`To Do (${tasks.filter(t => t.status === 'todo').length})`} />
                <Tab label={`In Progress (${tasks.filter(t => t.status === 'in_progress').length})`} />
                <Tab label={`Done (${tasks.filter(t => t.status === 'done').length})`} />
              </Tabs>
              
              <Box sx={{ p: 2 }}>
                <Grid container spacing={2}>
                  {filteredTasks.map((task) => (
                    <Grid item xs={12} key={task.id}>
                      <Card 
                        variant="outlined" 
                        sx={{ cursor: 'pointer' }}
                        onClick={() => handleTaskClick(task)}
                      >
                        <CardContent>
                          <Box display="flex" justifyContent="space-between" alignItems="flex-start">
                            <Box>
                              <Typography variant="h6" component="h2">
                                {task.title}
                              </Typography>
                              <Typography variant="body2" color="textSecondary" paragraph>
                                {task.description || 'No description provided'}
                              </Typography>
                              <Box display="flex" gap={1} flexWrap="wrap">
                                <Chip
                                  label={task.status.replace('_', ' ').toUpperCase()}
                                  color={getStatusColor(task.status)}
                                  size="small"
                                />
                                <Chip
                                  label={task.priority.toUpperCase()}
                                  color={getPriorityColor(task.priority)}
                                  size="small"
                                />
                                {task.deadline && (
                                  <Chip
                                    icon={<Schedule />}
                                    label={new Date(task.deadline).toLocaleDateString()}
                                    size="small"
                                    variant="outlined"
                                  />
                                )}
                              </Box>
                            </Box>
                            <Box>
                              <IconButton
                                size="small"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleOpenDialog(task);
                                }}
                              >
                                <Edit />
                              </IconButton>
                              <IconButton
                                size="small"
                                color="error"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleDelete(task.id);
                                }}
                              >
                                <Delete />
                              </IconButton>
                            </Box>
                          </Box>
                        </CardContent>
                      </Card>
                    </Grid>
                  ))}
                </Grid>
              </Box>
            </Card>
          </Grid>

          <Grid item xs={12} md={4}>
            {selectedTask && (
              <Card>
                <CardContent>
                  <Typography variant="h6" gutterBottom>
                    Task Details
                  </Typography>
                  <Typography variant="body1" paragraph>
                    {selectedTask.title}
                  </Typography>
                  <Typography variant="body2" color="textSecondary" paragraph>
                    {selectedTask.description || 'No description provided'}
                  </Typography>
                  
                  <Divider sx={{ my: 2 }} />
                  
                  <Typography variant="h6" gutterBottom>
                    Comments
                  </Typography>
                  
                  <List>
                    {comments.map((comment) => (
                      <ListItem key={comment.id} alignItems="flex-start">
                        <ListItemText
                          primary={comment.content}
                          secondary={
                            <Box>
                              <Typography variant="caption" color="textSecondary">
                                {comment.user?.name} - {new Date(comment.created_at).toLocaleString()}
                              </Typography>
                            </Box>
                          }
                        />
                      </ListItem>
                    ))}
                  </List>
                  
                  <Box sx={{ mt: 2 }}>
                    <TextField
                      fullWidth
                      multiline
                      rows={2}
                      placeholder="Add a comment..."
                      value={newComment}
                      onChange={(e) => setNewComment(e.target.value)}
                    />
                    <Button
                      variant="contained"
                      size="small"
                      sx={{ mt: 1 }}
                      onClick={handleAddComment}
                      disabled={!newComment.trim()}
                    >
                      Add Comment
                    </Button>
                  </Box>
                </CardContent>
              </Card>
            )}
          </Grid>
        </Grid>

        {/* Task Dialog */}
        <Dialog open={openDialog} onClose={handleCloseDialog} maxWidth="sm" fullWidth>
          <DialogTitle>
            {editingTask ? 'Edit Task' : 'Create New Task'}
          </DialogTitle>
          <DialogContent>
            <Grid container spacing={2} sx={{ mt: 1 }}>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Task Title"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  required
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Description"
                  multiline
                  rows={3}
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <FormControl fullWidth>
                  <InputLabel>Project</InputLabel>
                  <Select
                    value={formData.project_id}
                    label="Project"
                    onChange={(e) => setFormData({ ...formData, project_id: e.target.value })}
                    required
                  >
                    {projects.map((project) => (
                      <MenuItem key={project.id} value={project.id}>
                        {project.title}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12} sm={6}>
                <FormControl fullWidth>
                  <InputLabel>Status</InputLabel>
                  <Select
                    value={formData.status}
                    label="Status"
                    onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                  >
                    <MenuItem value="todo">To Do</MenuItem>
                    <MenuItem value="in_progress">In Progress</MenuItem>
                    <MenuItem value="done">Done</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12} sm={6}>
                <FormControl fullWidth>
                  <InputLabel>Priority</InputLabel>
                  <Select
                    value={formData.priority}
                    label="Priority"
                    onChange={(e) => setFormData({ ...formData, priority: e.target.value })}
                  >
                    <MenuItem value="low">Low</MenuItem>
                    <MenuItem value="medium">Medium</MenuItem>
                    <MenuItem value="high">High</MenuItem>
                    <MenuItem value="urgent">Urgent</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12} sm={6}>
                <DatePicker
                  label="Deadline"
                  value={formData.deadline}
                  onChange={(date) => setFormData({ ...formData, deadline: date })}
                  renderInput={(params) => <TextField {...params} fullWidth />}
                />
              </Grid>
            </Grid>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleCloseDialog}>Cancel</Button>
            <Button onClick={handleSubmit} variant="contained">
              {editingTask ? 'Update' : 'Create'}
            </Button>
          </DialogActions>
        </Dialog>
      </Container>
    </LocalizationProvider>
  );
};

export default Tasks;
